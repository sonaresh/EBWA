from __future__ import annotations
import hashlib, json, time
from pathlib import Path
import jwt
from .crypto import verify_identity_token, verify_object
from .models import AuthorizationRequest, AuthorizationResponse
from .settings import IDENTITY_ISSUER, DEFAULT_DECISION_TTL
from .store import Store

class EBWAEngine:
    def __init__(self, store: Store, identity_public: Path, provenance_public: Path):
        self.store = store
        self.identity_public = identity_public
        self.provenance_public = provenance_public
        self.identity_plane_available = True
        self.provenance_plane_available = True
        self.policy_plane_available = True
        self.posture_plane_available = True

    def _cache_key(self, req, claims):
        raw = "|".join([claims.get("sub","?"), req.artifact_digest, req.resource, req.action, req.config])
        return hashlib.sha256(raw.encode()).hexdigest()

    def authorize(self, req: AuthorizationRequest) -> AuthorizationResponse:
        started = time.perf_counter()
        prior = self.store.decision_get(req.request_id)
        if prior:
            prior["cache_hit"] = prior.get("cache_hit", False)
            return AuthorizationResponse(**prior)

        # Every configuration needs native workload identity for policy evaluation.
        claims = None
        identity_ok = False
        identity_reason = "identity unavailable"
        if self.identity_plane_available:
            try:
                claims = verify_identity_token(req.identity_token, self.identity_public, IDENTITY_ISSUER)
                if self.store.is_revoked("identity", claims.get("jti", "")) or self.store.is_revoked("workload", claims["sub"]):
                    identity_reason = "identity revoked"
                else:
                    identity_ok = True
                    identity_reason = "identity valid"
            except jwt.ExpiredSignatureError:
                identity_reason = "identity expired"
            except Exception as e:
                identity_reason = f"identity invalid: {type(e).__name__}"

        cache_key = self._cache_key(req, claims or {"sub": "invalid"})
        if claims and not req.force_fresh:
            cached = self.store.cache_get(cache_key)
            if cached:
                cached["request_id"] = req.request_id
                cached["cache_hit"] = True
                cached["latency_ms"] = (time.perf_counter() - started) * 1000
                self.store.decision_put(req.request_id, cached)
                return AuthorizationResponse(**cached)

        workload_id = claims.get("sub") if claims else None
        trust_domain = claims.get("trust_domain") if claims else None
        token_artifact = claims.get("artifact_digest") if claims else None
        scopes = set(claims.get("scopes", [])) if claims else set()

        # Configuration-specific evaluation prevents the ablation benchmark from
        # paying the cost of controls that the configuration does not use.
        need_artifact = req.config in {"B", "D", "E"}
        need_provenance = req.config in {"C", "D", "E"}
        need_posture = req.config in {"D", "E"}

        policy = self.store.get_policy(req.resource, req.action) if self.policy_plane_available else None
        policy_ok = False
        policy_reason = "policy unavailable"
        policy_obj = None
        if policy:
            policy_obj = json.loads(policy["policy_json"])
            policy_ok = bool(
                identity_ok
                and trust_domain in policy_obj["allowed_trust_domains"]
                and policy_obj["required_scope"] in scopes
            )
            policy_reason = "policy allows" if policy_ok else "policy denies"

        exact_artifact_ok = False
        if need_artifact:
            exact_artifact_ok = bool(
                identity_ok
                and token_artifact == req.artifact_digest
                and not self.store.is_revoked("artifact", req.artifact_digest)
            )

        provenance = None
        provenance_ok = False
        provenance_reason = "not evaluated in this configuration"
        if need_provenance:
            provenance_reason = "provenance unavailable"
            provenance = self.store.get_provenance(req.artifact_digest) if self.provenance_plane_available else None
            if provenance:
                env = json.loads(provenance["envelope_json"])
                provenance_ok = (
                    not provenance["revoked"]
                    and provenance["expires_at"] >= time.time()
                    and not self.store.is_revoked("signer", provenance["signer_id"])
                    and env.get("artifact_digest") == req.artifact_digest
                    and verify_object(env, provenance["signature"], self.provenance_public)
                )
                provenance_reason = "provenance valid" if provenance_ok else "provenance invalid/stale/revoked"

        posture = None
        posture_obj = None
        posture_ok = False
        isolation_ok = False
        posture_reason = "not evaluated in this configuration"
        if need_posture:
            posture_reason = "posture unavailable"
            posture = self.store.get_posture(workload_id) if (workload_id and self.posture_plane_available) else None
            if posture:
                posture_obj = json.loads(posture["posture_json"])
                posture_ok = bool(
                    posture["expires_at"] >= time.time()
                    and posture_obj.get("healthy")
                    and posture_obj.get("telemetry_ok")
                )
                posture_reason = "posture admissible" if posture_ok else "posture degraded/stale"
                isolation_ok = bool(posture_obj.get("isolation_ok"))

        if req.config == "A":
            checks = [("identity", identity_ok), ("policy", policy_ok)]
        elif req.config == "B":
            checks = [("identity", identity_ok), ("exact_artifact", exact_artifact_ok), ("policy", policy_ok)]
        elif req.config == "C":
            checks = [("identity", identity_ok), ("provenance", provenance_ok), ("policy", policy_ok)]
        else:
            checks = [
                ("identity", identity_ok),
                ("exact_artifact", exact_artifact_ok),
                ("provenance", provenance_ok),
                ("policy", policy_ok),
                ("posture", posture_ok),
            ]
            if req.config == "E":
                checks.append(("isolation", isolation_ok))

        failed = [name for name, ok in checks if not ok]
        allow = not failed

        revoked_trigger = False
        if claims:
            revoked_trigger = self.store.is_revoked("identity", claims.get("jti", "")) or self.store.is_revoked("workload", claims.get("sub", ""))
        if provenance:
            revoked_trigger = revoked_trigger or bool(provenance["revoked"]) or self.store.is_revoked("signer", provenance["signer_id"])

        decision = "ALLOW" if allow else ("REVOKE" if revoked_trigger else "DENY")
        reason = "all required evidence predicates satisfied" if allow else "failed predicates: " + ", ".join(failed)

        evidence = {
            "identity": {
                "evaluated": True,
                "bound_to_decision": True,
                "ok": identity_ok,
                "reason": identity_reason,
                "jti": claims.get("jti") if claims else None,
            },
            "artifact": {
                "evaluated": need_artifact,
                "bound_to_decision": need_artifact,
                "ok": exact_artifact_ok if need_artifact else None,
                "requested_digest": req.artifact_digest,
                "identity_digest": token_artifact,
            },
            "provenance": {
                "evaluated": need_provenance,
                "bound_to_decision": need_provenance,
                "ok": provenance_ok if need_provenance else None,
                "reason": provenance_reason,
                "signer_id": provenance.get("signer_id") if provenance else None,
            },
            "policy": {
                "evaluated": True,
                "bound_to_decision": True,
                "ok": policy_ok,
                "reason": policy_reason,
                "version": policy.get("version") if policy else None,
            },
            "posture": {
                "evaluated": need_posture,
                "bound_to_decision": need_posture,
                "ok": posture_ok if need_posture else None,
                "reason": posture_reason,
                "isolation_ok": isolation_ok if need_posture else None,
                "isolation_bound_to_decision": req.config == "E",
            },
            "evidence_version": self.store.get_state("evidence_version"),
        }

        resp = AuthorizationResponse(
            request_id=req.request_id,
            decision=decision,
            reason=reason,
            config=req.config,
            workload_id=workload_id,
            trust_domain=trust_domain,
            artifact_digest=req.artifact_digest,
            resource=req.resource,
            action=req.action,
            evidence=evidence,
            latency_ms=(time.perf_counter() - started) * 1000,
        )
        d = resp.model_dump()
        self.store.decision_put(req.request_id, d)
        if allow and not req.force_fresh and req.config in {"A", "B", "C", "D", "E"}:
            ttl = 0 if (policy_obj and policy_obj.get("require_fresh")) else DEFAULT_DECISION_TTL
            if ttl > 0:
                self.store.cache_put(cache_key, d, ttl)
        self.store.event("authorization", req.request_id, {"decision": decision, "config": req.config, "workload": workload_id, "resource": req.resource})
        return resp
