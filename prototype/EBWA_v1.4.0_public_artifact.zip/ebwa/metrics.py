from __future__ import annotations
import math
import statistics


def percentile(xs, p):
    xs = sorted(float(x) for x in xs)
    if not xs:
        return 0.0
    k = (len(xs) - 1) * (p / 100.0)
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return xs[int(k)]
    return xs[f] * (c - k) + xs[c] * (k - f)


def mean_ci95(xs):
    """Normal-approximation 95% CI for independent trial-level measurements."""
    xs = [float(x) for x in xs]
    if not xs:
        return {"mean": 0.0, "low": 0.0, "high": 0.0, "n": 0}
    mean = statistics.fmean(xs)
    if len(xs) == 1:
        return {"mean": mean, "low": mean, "high": mean, "n": 1}
    sem = statistics.stdev(xs) / math.sqrt(len(xs))
    margin = 1.96 * sem
    return {"mean": mean, "low": mean - margin, "high": mean + margin, "n": len(xs)}


def ebar(decisions):
    protected = len(decisions)
    if not protected:
        return 0.0
    bound = 0
    for d in decisions:
        ev = d.get("evidence", {})
        required = ["identity", "artifact", "provenance", "policy", "posture"]
        if all(ev.get(k, {}).get("bound_to_decision") and ev.get(k, {}).get("ok") for k in required):
            bound += 1
    return bound / protected


def nde(drift_windows, observation_window):
    if not drift_windows:
        return 0.0
    return sum(drift_windows) / (observation_window * len(drift_windows)) if observation_window > 0 else 0.0


def sdo95(full_latencies, base_latencies):
    """95th percentile of *paired* D-A request latency deltas.

    Callers must ensure that full_latencies[i] and base_latencies[i] represent
    the same logical request in the same trial. For unpaired runs, report the
    difference between configuration p95 values instead.
    """
    n = min(len(full_latencies), len(base_latencies))
    diffs = [float(full_latencies[i]) - float(base_latencies[i]) for i in range(n)]
    return percentile(diffs, 95)
