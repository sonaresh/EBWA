from __future__ import annotations
import argparse, json
from pathlib import Path
from .scenarios import SCENARIOS, run_scenario

def main():
    p=argparse.ArgumentParser(); p.add_argument("--all",action="store_true"); p.add_argument("--output",default="evidence/scenarios.json")
    args=p.parse_args(); configs=["A","B","C","D","E"]
    rows=[]
    for s in SCENARIOS:
        for c in configs:
            r=run_scenario(s,c)
            rows.append({"scenario":s.id,"name":s.name,"family":s.attack_family,"config":c,"decision":r.decision,"reason":r.reason,"latency_ms":r.latency_ms,"evidence":r.evidence})
    out=Path(args.output); out.parent.mkdir(parents=True,exist_ok=True); out.write_text(json.dumps(rows,indent=2))
    full=[x for x in rows if x["config"]=="D"]
    passed=0
    for x,s in zip(full,SCENARIOS):
        exp=s.expected_full
        ok=(x["decision"]==exp) if exp in {"ALLOW","DENY","REVOKE"} else True
        passed+=ok
        print(f"{s.id} D {x['decision']:<6} {'PASS' if ok else 'CHECK'} {s.name}")
    print(f"wrote {len(rows)} configuration-scenario results to {out}")

if __name__=="__main__": main()
