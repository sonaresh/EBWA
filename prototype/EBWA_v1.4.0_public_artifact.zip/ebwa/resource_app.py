from __future__ import annotations
import os, uuid
import httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

GATEWAY=os.getenv("EBWA_GATEWAY_URL","http://127.0.0.1:8000")
app=FastAPI(title="EBWA Protected Resource",version="1.0.0")

class ResourceRequest(BaseModel):
    artifact_digest:str
    config:str="D"

@app.get("/health")
def health(): return {"status":"ok","gateway":GATEWAY}

@app.post("/v1/secret")
def secret(req:ResourceRequest,authorization:str|None=Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "): raise HTTPException(401,"missing workload identity")
    token=authorization.split(" ",1)[1]
    payload={"identity_token":token,"artifact_digest":req.artifact_digest,"resource":"secret://payments/db","action":"read","config":req.config,"request_id":str(uuid.uuid4())}
    try:
        r=httpx.post(GATEWAY+"/v1/authorize",json=payload,timeout=5)
        r.raise_for_status(); decision=r.json()
    except Exception as e:
        raise HTTPException(503,f"authorization service unavailable: {type(e).__name__}")
    if decision["decision"]!="ALLOW": raise HTTPException(403,{"message":"EBWA denied access","decision":decision})
    return {"secret":"demo-db-password-not-real","authorized_by":decision}
