from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
import statistics
import sys
import time
import tracemalloc
import uuid
from collections import defaultdict
from pathlib import Path

from .admin import create_provenance, issue_identity, upsert_policy, upsert_posture
from .metrics import ebar, mean_ci95, nde, percentile
from .models import AuthorizationRequest
from .runtime import engine, store

CONFIGS = ["A", "B", "C", "D", "E"]
ACTION = "read"


def _progress(message: str) -> None:
    print(message, file=sys.stderr, flush=True)


def _digest(label: str) -> str:
    return "sha256:" + hashlib.sha256(label.encode("utf-8")).hexdigest()


def build_scale_corpus(scale: int, seed: int = 2762, evidence_ttl_s: int = 86400):
    """Create a deterministic, physically instantiated logical enterprise corpus."""
    scale = max(1, int(scale))
    rng = random.Random(seed)
    store.reset()
    engine.identity_plane_available = True
    engine.provenance_plane_available = True
    engine.policy_plane_available = True
    engine.posture_plane_available = True

    trust_domain_count = max(2, min(16, int(scale ** 0.5) or 2)) if scale > 1 else 1
    artifact_count = max(1, min(scale, 256))
    policy_count = max(1, min(scale, 128))

    trust_domains = [f"prod.td-{i:02d}.example" for i in range(trust_domain_count)]
    artifacts = [_digest(f"ebwa-artifact-{i}") for i in range(artifact_count)]
    resources = [f"secret://ebwa/resource-{i:04d}" for i in range(policy_count)]

    for digest in artifacts:
        create_provenance(digest, source_repo="https://example.invalid/ebwa", commit_sha=digest[-12:], ttl=evidence_ttl_s)

    policy_domains = [trust_domains[i % trust_domain_count] for i in range(policy_count)]
    for i, resource in enumerate(resources):
        upsert_policy(resource, ACTION, [policy_domains[i]], "secret:read", version=f"v1-{i}")

    workloads = []
    for i in range(scale):
        policy_idx = i % policy_count
        resource = resources[policy_idx]
        trust_domain = policy_domains[policy_idx]
        artifact = artifacts[i % artifact_count]
        workload_id = f"workload-{i:06d}"
        upsert_posture(workload_id, healthy=True, isolation_ok=True, telemetry_ok=True, ttl=evidence_ttl_s)
        token = issue_identity(workload_id, trust_domain, artifact, ["secret:read"], ttl=evidence_ttl_s)
        workloads.append({
            "index": i,
            "workload_id": workload_id,
            "trust_domain": trust_domain,
            "artifact_digest": artifact,
            "resource": resource,
            "action": ACTION,
            "identity_token": token,
        })

    rng.shuffle(workloads)
    return {
        "workloads": workloads,
        "dimensions": {
            "workload_identities": scale,
            "posture_objects": scale,
            "artifact_provenance_objects": artifact_count,
            "policy_objects": policy_count,
            "trust_domains": trust_domain_count,
        },
    }


def _request(w, config: str, force_fresh: bool):
    return AuthorizationRequest(
        identity_token=w["identity_token"],
        artifact_digest=w["artifact_digest"],
        resource=w["resource"],
        action=w["action"],
        config=config,
        request_id=str(uuid.uuid4()),
        force_fresh=force_fresh,
    )


def _warm_cache(workloads, indices, configs):
    for config in configs:
        for idx in sorted(set(indices)):
            r = engine.authorize(_request(workloads[idx], config, force_fresh=False))
            if r.decision != "ALLOW":
                raise RuntimeError(f"cache warm failed: config={config} workload={idx} decision={r.decision}")


def _select_indices(rng: random.Random, workload_count: int, total: int, profile: str, high_reuse_size: int):
    if profile == "fresh":
        return [rng.randrange(workload_count) for _ in range(total)], workload_count
    if profile == "cached-high-reuse":
        working_set = max(1, min(workload_count, high_reuse_size))
        pool = list(range(working_set))
        return [pool[rng.randrange(working_set)] for _ in range(total)], working_set
    if profile == "cached-large-working-set":
        return [rng.randrange(workload_count) for _ in range(total)], workload_count
    raise ValueError(profile)


def run_mode(
    workloads,
    repetitions: int,
    trials: int,
    profile: str,
    seed: int,
    warmup: int,
    raw_writer,
    high_reuse_size: int,
):
    force_fresh = profile == "fresh"
    all_latencies = defaultdict(list)
    all_decisions = defaultdict(list)
    trial_stats = defaultdict(list)
    paired_deltas = []
    trial_sdo95 = []
    measured_cache_hits = defaultdict(int)
    measured_counts = defaultdict(int)
    measured_service_time_s = defaultdict(float)
    effective_working_sets = []

    for trial in range(trials):
        _progress(f"[{profile}] trial {trial + 1}/{trials} starting")
        rng = random.Random(seed + trial * 1009 + {"fresh": 0, "cached-high-reuse": 500_000, "cached-large-working-set": 900_000}[profile])
        indices, effective_ws = _select_indices(
            rng, len(workloads), repetitions + warmup, profile, high_reuse_size
        )
        effective_working_sets.append(effective_ws)

        if profile != "fresh":
            # Pre-warm only the workload keys that can appear in the measured phase.
            _warm_cache(workloads, indices[warmup:], CONFIGS)

        for round_idx in range(warmup):
            order = CONFIGS[:]
            rng.shuffle(order)
            w = workloads[indices[round_idx]]
            for config in order:
                engine.authorize(_request(w, config, force_fresh=force_fresh))

        lat_by_config = defaultdict(list)
        trial_paired = []
        trial_started_wall = time.perf_counter()
        trial_started_cpu = time.process_time()
        tracemalloc.start()

        for round_idx in range(repetitions):
            workload_idx = indices[warmup + round_idx]
            w = workloads[workload_idx]
            order = CONFIGS[:]
            rng.shuffle(order)
            round_results = {}

            for order_pos, config in enumerate(order):
                call_started = time.perf_counter()
                resp = engine.authorize(_request(w, config, force_fresh=force_fresh))
                call_elapsed = time.perf_counter() - call_started
                measured_service_time_s[config] += call_elapsed

                d = resp.model_dump()
                round_results[config] = d
                lat_by_config[config].append(resp.latency_ms)
                all_latencies[config].append(resp.latency_ms)
                all_decisions[config].append(d)
                measured_cache_hits[config] += int(resp.cache_hit)
                measured_counts[config] += 1
                raw_writer.writerow({
                    "profile": profile,
                    "trial": trial + 1,
                    "round": round_idx + 1,
                    "order_position": order_pos + 1,
                    "config": config,
                    "workload_index": workload_idx,
                    "workload_id": w["workload_id"],
                    "latency_ms": f"{resp.latency_ms:.9f}",
                    "external_call_elapsed_ms": f"{call_elapsed * 1000.0:.9f}",
                    "cache_hit": int(resp.cache_hit),
                    "decision": resp.decision,
                })

            delta = round_results["D"]["latency_ms"] - round_results["A"]["latency_ms"]
            paired_deltas.append(delta)
            trial_paired.append(delta)

            if repetitions >= 5000 and (round_idx + 1) % max(1000, repetitions // 5) == 0:
                _progress(f"[{profile}] trial {trial + 1}/{trials}: {round_idx + 1}/{repetitions} rounds")

        _current_mem, peak_mem = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        wall_elapsed = time.perf_counter() - trial_started_wall
        cpu_elapsed = time.process_time() - trial_started_cpu

        for config in CONFIGS:
            xs = lat_by_config[config]
            trial_stats[(config, "p50_ms")].append(percentile(xs, 50))
            trial_stats[(config, "p95_ms")].append(percentile(xs, 95))
            trial_stats[(config, "p99_ms")].append(percentile(xs, 99))
        trial_sdo95.append(percentile(trial_paired, 95))
        trial_stats[("ALL", "wall_time_s")].append(wall_elapsed)
        trial_stats[("ALL", "cpu_time_s")].append(cpu_elapsed)
        trial_stats[("ALL", "peak_python_memory_mb")].append(peak_mem / (1024 * 1024))
        _progress(f"[{profile}] trial {trial + 1}/{trials} complete in {wall_elapsed:.2f}s")

    config_rows = []
    for config in CONFIGS:
        xs = all_latencies[config]
        service_time = measured_service_time_s[config]
        serial_throughput = len(xs) / service_time if service_time > 0 else 0.0
        config_rows.append({
            "config": config,
            "profile": profile,
            "trials": trials,
            "repetitions_per_trial": repetitions,
            "samples": len(xs),
            "p50_ms": percentile(xs, 50),
            "p95_ms": percentile(xs, 95),
            "p99_ms": percentile(xs, 99),
            "p95_trial_ci95": mean_ci95(trial_stats[(config, "p95_ms")]),
            "per_config_serial_throughput_decisions_s": serial_throughput,
            "measured_service_time_s": service_time,
            "cache_hit_rate": measured_cache_hits[config] / measured_counts[config] if measured_counts[config] else 0.0,
            "EBAR": ebar(all_decisions[config]),
        })

    base = next(r for r in config_rows if r["config"] == "A")
    full = next(r for r in config_rows if r["config"] == "D")
    return {
        "profile": profile,
        "effective_working_set_mean": statistics.fmean(effective_working_sets),
        "configs": config_rows,
        "SDO95_paired_ms": percentile(paired_deltas, 95),
        "SDO95_paired_trial_ci95": mean_ci95(trial_sdo95),
        "p95_difference_D_minus_A_ms": full["p95_ms"] - base["p95_ms"],
        "EBAR_full": full["EBAR"],
        "trial_wall_time_s_ci95": mean_ci95(trial_stats[("ALL", "wall_time_s")]),
        "trial_cpu_time_s_ci95": mean_ci95(trial_stats[("ALL", "cpu_time_s")]),
        "peak_python_memory_mb_ci95": mean_ci95(trial_stats[("ALL", "peak_python_memory_mb")]),
    }


def run_drift_experiment(workload, events: int = 20, normalization_window_s: float = 1.0):
    """Measure cache invalidation + reauthorization after trust drift.

    NDE uses a fixed, declared normalization window per drift event so the
    denominator does not change simply because the host executes the loop faster.
    """
    windows_s = []
    rows = []
    experiment_start = time.perf_counter()

    for i in range(events):
        if events >= 20 and (i == 0 or (i + 1) % max(1, events // 4) == 0):
            _progress(f"[drift] event {i + 1}/{events}")
        upsert_posture(workload["workload_id"], healthy=True, isolation_ok=True, telemetry_ok=True, ttl=3600, reason="pre-drift")
        warm = engine.authorize(_request(workload, "D", force_fresh=False))
        if warm.decision != "ALLOW":
            raise RuntimeError("drift experiment could not establish initial ALLOW state")

        drift_start = time.perf_counter()
        upsert_posture(workload["workload_id"], healthy=False, isolation_ok=True, telemetry_ok=True, ttl=3600, reason="injected posture drift")
        blocked = engine.authorize(_request(workload, "D", force_fresh=False))
        drift_end = time.perf_counter()
        if blocked.decision == "ALLOW":
            raise RuntimeError("drift experiment failed: stale ALLOW survived posture invalidation")
        delay_s = drift_end - drift_start
        windows_s.append(delay_s)
        rows.append({
            "event": i + 1,
            "drift_type": "posture",
            "decision_after_drift": blocked.decision,
            "cache_hit_after_drift": blocked.cache_hit,
            "revocation_delay_ms": delay_s * 1000.0,
        })

    actual_wall_s = time.perf_counter() - experiment_start
    delays_ms = [x * 1000.0 for x in windows_s]
    return {
        "events": events,
        "actual_experiment_wall_time_s": actual_wall_s,
        "normalization_window_per_event_s": normalization_window_s,
        "NDE": nde(windows_s, normalization_window_s),
        "revocation_delay_ms": {
            "mean": statistics.fmean(delays_ms),
            "p50": percentile(delays_ms, 50),
            "p95": percentile(delays_ms, 95),
            "p99": percentile(delays_ms, 99),
        },
        "rows": rows,
    }


def main():
    p = argparse.ArgumentParser(description="Controlled EBWA-Bench v1.2 performance, cache, and drift evaluation")
    p.add_argument("--repetitions", type=int, default=1000, help="measured paired rounds per config per trial")
    p.add_argument("--trials", type=int, default=5, help="independent trials")
    p.add_argument("--warmup", type=int, default=100, help="excluded warm-up rounds per trial")
    p.add_argument("--scale", type=int, default=1000, help="number of instantiated workload identities/posture objects")
    p.add_argument("--seed", type=int, default=2762)
    p.add_argument("--drift-events", type=int, default=20)
    p.add_argument("--evidence-ttl-s", type=int, default=86400, help="benchmark-only TTL for identity/provenance/posture evidence; prevents wall-clock expiry during long runs")
    p.add_argument("--skip-drift", action="store_true", help="skip drift experiment when running a profile-only recovery/completion job")
    p.add_argument("--drift-window-s", type=float, default=1.0, help="fixed NDE normalization window per drift event")
    p.add_argument("--mode", choices=["fresh", "cached", "both"], default="both", help="compatibility switch; cached runs both cache profiles")
    p.add_argument("--cache-profile", choices=["high-reuse", "large-working-set", "both"], default="both")
    p.add_argument("--high-reuse-working-set", type=int, default=32, help="workloads used in cached high-reuse profile")
    p.add_argument("--output-dir", default="evidence/benchmark-v1.2")
    args = p.parse_args()

    if args.repetitions < 10 or args.trials < 1 or args.warmup < 0 or args.scale < 1 or args.drift_window_s <= 0 or args.evidence_ttl_s < 3600:
        raise SystemExit("invalid benchmark parameters")

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    _progress(f"[setup] building logical enterprise corpus at scale={args.scale}")
    corpus = build_scale_corpus(args.scale, args.seed, args.evidence_ttl_s)
    workloads = corpus["workloads"]
    _progress(f"[setup] corpus ready: {corpus['dimensions']}")

    profiles = []
    if args.mode in {"fresh", "both"}:
        profiles.append("fresh")
    if args.mode in {"cached", "both"}:
        if args.cache_profile in {"high-reuse", "both"}:
            profiles.append("cached-high-reuse")
        if args.cache_profile in {"large-working-set", "both"}:
            profiles.append("cached-large-working-set")

    raw_path = out / "raw_latency.csv"
    with raw_path.open("w", newline="", encoding="utf-8") as f:
        fieldnames = ["profile", "trial", "round", "order_position", "config", "workload_index", "workload_id", "latency_ms", "external_call_elapsed_ms", "cache_hit", "decision"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        mode_results = []
        for profile in profiles:
            result = run_mode(
                workloads, args.repetitions, args.trials, profile, args.seed,
                args.warmup, writer, args.high_reuse_working_set
            )
            mode_results.append(result)
            f.flush()
            checkpoint = {
                "benchmark_version": "1.2.1",
                "profile": profile,
                "parameters": {
                    "repetitions_per_config_per_trial": args.repetitions,
                    "trials": args.trials,
                    "warmup_rounds_per_trial": args.warmup,
                    "scale": args.scale,
                    "seed": args.seed,
                    "evidence_ttl_s": args.evidence_ttl_s,
                },
                "scale_dimensions": corpus["dimensions"],
                "result": result,
            }
            (out / f"checkpoint-{profile}.json").write_text(json.dumps(checkpoint, indent=2), encoding="utf-8")
            _progress(f"[{profile}] checkpoint written")

    if args.skip_drift:
        drift_result = {
            "events": 0,
            "actual_experiment_wall_time_s": 0.0,
            "normalization_window_per_event_s": args.drift_window_s,
            "NDE": None,
            "revocation_delay_ms": {"mean": None, "p50": None, "p95": None, "p99": None},
            "rows": [],
        }
    else:
        _progress("[drift] rebuilding clean corpus")
        drift_corpus = build_scale_corpus(max(1, min(args.scale, 1000)), args.seed + 77, args.evidence_ttl_s)
        drift_result = run_drift_experiment(
            drift_corpus["workloads"][0], args.drift_events, args.drift_window_s
        )

    summary = {
        "benchmark_version": "1.2.1",
        "timestamp": time.time(),
        "parameters": {
            "repetitions_per_config_per_trial": args.repetitions,
            "trials": args.trials,
            "warmup_rounds_per_trial": args.warmup,
            "scale": args.scale,
            "seed": args.seed,
            "mode": args.mode,
            "cache_profile": args.cache_profile,
            "high_reuse_working_set": args.high_reuse_working_set,
            "drift_events": args.drift_events,
            "drift_window_s": args.drift_window_s,
            "evidence_ttl_s": args.evidence_ttl_s,
            "skip_drift": args.skip_drift,
        },
        "scale_dimensions": corpus["dimensions"],
        "profiles": mode_results,
        "drift": {k: v for k, v in drift_result.items() if k != "rows"},
        "notes": [
            "A-E are evaluated on the same logical workload per paired round; configuration execution order is randomized.",
            "Warm-up rounds are excluded from statistics.",
            "Per-config serial throughput uses only externally measured wall time spent executing that configuration's authorize() calls; it is not a concurrent-system throughput claim.",
            "SDO95_paired_ms is the p95 of paired D-A latency deltas for matched logical requests.",
            "SDO95_paired_trial_ci95 reports a 95% CI across independent trial-level paired SDO95 values.",
            "cached-high-reuse uses a bounded hot working set; cached-large-working-set samples the full logical workload population.",
            "Evidence updates invalidate cache through the evidence-version mechanism.",
            "NDE uses the declared fixed normalization_window_per_event_s; raw revocation-delay distributions remain the primary drift result.",
            "Benchmark corpus identity, provenance, and posture TTL is explicitly extended for long-running experiments so wall-clock expiry does not confound performance profiles.",
            "Peak memory is Python allocator peak measured with tracemalloc, not host RSS.",
        ],
    }

    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    with (out / "latency_summary.csv").open("w", newline="", encoding="utf-8") as f:
        fields = [
            "profile", "config", "trials", "repetitions_per_trial", "samples",
            "p50_ms", "p95_ms", "p99_ms", "per_config_serial_throughput_decisions_s",
            "measured_service_time_s", "cache_hit_rate", "EBAR", "p95_ci95_low", "p95_ci95_high"
        ]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for result in mode_results:
            for row in result["configs"]:
                w.writerow({
                    "profile": row["profile"], "config": row["config"], "trials": row["trials"],
                    "repetitions_per_trial": row["repetitions_per_trial"], "samples": row["samples"],
                    "p50_ms": row["p50_ms"], "p95_ms": row["p95_ms"], "p99_ms": row["p99_ms"],
                    "per_config_serial_throughput_decisions_s": row["per_config_serial_throughput_decisions_s"],
                    "measured_service_time_s": row["measured_service_time_s"], "cache_hit_rate": row["cache_hit_rate"],
                    "EBAR": row["EBAR"], "p95_ci95_low": row["p95_trial_ci95"]["low"], "p95_ci95_high": row["p95_trial_ci95"]["high"],
                })

    with (out / "drift_results.csv").open("w", newline="", encoding="utf-8") as f:
        if drift_result["rows"]:
            w = csv.DictWriter(f, fieldnames=list(drift_result["rows"][0].keys()))
            w.writeheader()
            w.writerows(drift_result["rows"])
        else:
            f.write("event,drift_type,decision_after_drift,cache_hit_after_drift,revocation_delay_ms\n")

    _progress(f"[done] results written to {out}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
