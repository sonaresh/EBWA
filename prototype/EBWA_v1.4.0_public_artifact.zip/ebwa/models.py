from __future__ import annotations
from typing import Literal, Optional
from pydantic import BaseModel, Field

ConfigName = Literal["A", "B", "C", "D", "E"]
Decision = Literal["ALLOW", "DENY", "REVOKE"]

class IdentityIssueRequest(BaseModel):
    workload_id: str
    trust_domain: str
    artifact_digest: str
    scopes: list[str] = Field(default_factory=list)
    ttl_seconds: int = 300

class ProvenanceCreateRequest(BaseModel):
    artifact_digest: str
    source_repo: str
    commit_sha: str
    builder_id: str
    slsa_level: int = 3
    ttl_seconds: int = 3600

class PolicyUpsertRequest(BaseModel):
    resource: str
    action: str
    allowed_trust_domains: list[str]
    required_scope: str
    require_fresh: bool = False
    require_isolation: bool = False
    version: str = "v1"

class PostureUpsertRequest(BaseModel):
    workload_id: str
    healthy: bool = True
    isolation_ok: bool = True
    telemetry_ok: bool = True
    ttl_seconds: int = 60
    reason: str = "healthy"

class AuthorizationRequest(BaseModel):
    identity_token: str
    artifact_digest: str
    resource: str
    action: str
    config: ConfigName = "D"
    request_id: str
    force_fresh: bool = False

class AuthorizationResponse(BaseModel):
    request_id: str
    decision: Decision
    reason: str
    config: ConfigName
    workload_id: Optional[str] = None
    trust_domain: Optional[str] = None
    artifact_digest: str
    resource: str
    action: str
    evidence: dict = Field(default_factory=dict)
    cache_hit: bool = False
    latency_ms: float = 0.0

class RevocationRequest(BaseModel):
    kind: Literal["identity", "artifact", "signer", "policy", "workload"]
    subject: str
    reason: str
