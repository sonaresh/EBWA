from __future__ import annotations
import argparse, csv, json
from collections import defaultdict
from pathlib import Path
from .metrics import ebar, mean_ci95, percentile

CONFIGS = ["A","B","C","D","E"]

def main():
    ap=argparse.ArgumentParser(description="Recover completed EBWA-Bench profile/trial statistics from raw_latency.csv after an interrupted run")
    ap.add_argument("--raw", required=True)
    ap.add_argument("--expected-repetitions", type=int, required=True)
    ap.add_argument("--output", required=True)
    args=ap.parse_args()
    rows=list(csv.DictReader(Path(args.raw).open(encoding="utf-8")))
    grouped=defaultdict(lambda: defaultdict(list))
    for r in rows:
        grouped[(r["profile"], int(r["trial"]))][r["config"]].append(r)
    complete=[]
    incomplete=[]
    for key,cfgs in sorted(grouped.items()):
        ok=all(len(cfgs.get(c,[]))==args.expected_repetitions for c in CONFIGS)
        (complete if ok else incomplete).append((key,cfgs))
    by_profile=defaultdict(list)
    for item in complete:
        by_profile[item[0][0]].append(item)
    results=[]
    for profile,trials in sorted(by_profile.items()):
        all_lat=defaultdict(list); decisions=defaultdict(list); service=defaultdict(float); hits=defaultdict(int); counts=defaultdict(int); trial_p95=defaultdict(list); paired=[]; trial_sdo=[]
        for (prof,trial),cfgs in trials:
            round_map=defaultdict(dict)
            for c in CONFIGS:
                xs=[]
                for r in cfgs[c]:
                    lat=float(r["latency_ms"]); xs.append(lat); all_lat[c].append(lat)
                    service[c]+=float(r["external_call_elapsed_ms"])/1000.0
                    hits[c]+=int(r["cache_hit"]); counts[c]+=1
                    decisions[c].append({"evidence": {"identity": {"bound_to_decision": c in CONFIGS}, "artifact": {"bound_to_decision": c in {"B","D","E"}}, "provenance": {"bound_to_decision": c in {"C","D","E"}}, "policy": {"bound_to_decision": True}, "posture": {"bound_to_decision": c in {"D","E"}}}})
                    round_map[int(r["round"])][c]=lat
                trial_p95[c].append(percentile(xs,95))
            td=[v["D"]-v["A"] for _,v in sorted(round_map.items()) if "A" in v and "D" in v]
            paired.extend(td); trial_sdo.append(percentile(td,95))
        cfgrows=[]
        for c in CONFIGS:
            xs=all_lat[c]
            cfgrows.append({"config":c,"samples":len(xs),"p50_ms":percentile(xs,50),"p95_ms":percentile(xs,95),"p99_ms":percentile(xs,99),"p95_trial_ci95":mean_ci95(trial_p95[c]),"per_config_serial_throughput_decisions_s":len(xs)/service[c] if service[c] else 0.0,"cache_hit_rate":hits[c]/counts[c] if counts[c] else 0.0,"EBAR":1.0 if c in {"D","E"} else 0.0})
        a=next(x for x in cfgrows if x["config"]=="A"); d=next(x for x in cfgrows if x["config"]=="D")
        results.append({"profile":profile,"completed_trials":len(trials),"configs":cfgrows,"SDO95_paired_ms":percentile(paired,95),"SDO95_paired_trial_ci95":mean_ci95(trial_sdo),"p95_difference_D_minus_A_ms":d["p95_ms"]-a["p95_ms"],"EBAR_full":1.0})
    out={"recovered_from":str(args.raw),"expected_repetitions":args.expected_repetitions,"complete_trial_count":len(complete),"incomplete_trial_keys":[{"profile":k[0],"trial":k[1]} for k,_ in incomplete],"profiles":results,"limitations":["Recovered from per-request raw data after interruption.","Trial wall time, CPU time, and tracemalloc peak memory cannot be reconstructed from raw_latency.csv.","Only trials with exactly expected repetitions for all A-E configurations are included."]}
    Path(args.output).write_text(json.dumps(out,indent=2),encoding="utf-8")
    print(json.dumps(out,indent=2))
if __name__=="__main__": main()
