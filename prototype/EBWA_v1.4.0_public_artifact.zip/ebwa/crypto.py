from __future__ import annotations
import base64, hashlib, json, time
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization
import jwt


def canonical_json(obj: dict) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def ensure_keypair(private_path: Path, public_path: Path) -> None:
    private_path.parent.mkdir(parents=True, exist_ok=True)
    if private_path.exists() and public_path.exists():
        return
    priv = Ed25519PrivateKey.generate()
    pub = priv.public_key()
    private_path.write_bytes(priv.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8,
        serialization.NoEncryption(),
    ))
    public_path.write_bytes(pub.public_bytes(
        serialization.Encoding.PEM,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    ))


def load_private(path: Path) -> Ed25519PrivateKey:
    return serialization.load_pem_private_key(path.read_bytes(), password=None)


def load_public(path: Path) -> Ed25519PublicKey:
    return serialization.load_pem_public_key(path.read_bytes())


def sign_object(obj: dict, private_path: Path) -> str:
    sig = load_private(private_path).sign(canonical_json(obj))
    return base64.urlsafe_b64encode(sig).decode().rstrip("=")


def verify_object(obj: dict, signature: str, public_path: Path) -> bool:
    try:
        padding = "=" * ((4 - len(signature) % 4) % 4)
        sig = base64.urlsafe_b64decode(signature + padding)
        load_public(public_path).verify(sig, canonical_json(obj))
        return True
    except Exception:
        return False


def issue_identity_token(claims: dict, private_path: Path, issuer: str, ttl: int = 300) -> str:
    now = int(time.time())
    payload = {**claims, "iss": issuer, "iat": now, "nbf": now, "exp": now + ttl, "jti": sha256_hex(canonical_json({**claims, "iat": now}))[:24]}
    key = private_path.read_text()
    return jwt.encode(payload, key, algorithm="EdDSA")


def verify_identity_token(token: str, public_path: Path, issuer: str) -> dict:
    return jwt.decode(token, public_path.read_text(), algorithms=["EdDSA"], issuer=issuer, options={"require": ["exp", "iat", "iss", "sub"]})
