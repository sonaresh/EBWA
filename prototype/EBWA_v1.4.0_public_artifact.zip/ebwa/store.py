from __future__ import annotations
import json, sqlite3, threading, time
from pathlib import Path
from typing import Any

SCHEMA = """
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS provenance(
 artifact_digest TEXT PRIMARY KEY, envelope_json TEXT NOT NULL, signature TEXT NOT NULL,
 created_at REAL NOT NULL, expires_at REAL NOT NULL, signer_id TEXT NOT NULL, revoked INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS policy(
 resource TEXT NOT NULL, action TEXT NOT NULL, policy_json TEXT NOT NULL, version TEXT NOT NULL,
 updated_at REAL NOT NULL, PRIMARY KEY(resource, action)
);
CREATE TABLE IF NOT EXISTS posture(
 workload_id TEXT PRIMARY KEY, posture_json TEXT NOT NULL, updated_at REAL NOT NULL, expires_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS revocations(
 kind TEXT NOT NULL, subject TEXT NOT NULL, reason TEXT NOT NULL, ts REAL NOT NULL,
 PRIMARY KEY(kind, subject)
);
CREATE TABLE IF NOT EXISTS decision_cache(
 cache_key TEXT PRIMARY KEY, response_json TEXT NOT NULL, created_at REAL NOT NULL, expires_at REAL NOT NULL,
 evidence_version TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS decisions(
 request_id TEXT PRIMARY KEY, ts REAL NOT NULL, response_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS events(
 id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, event_type TEXT NOT NULL, subject TEXT NOT NULL, details_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS state(
 key TEXT PRIMARY KEY, value TEXT NOT NULL
);
"""

class Store:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self._lock = threading.RLock()
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        with self._conn:
            self._conn.executescript(SCHEMA)
            self._conn.execute("INSERT OR IGNORE INTO state(key,value) VALUES('evidence_version','1')")

    def reset(self):
        with self._lock, self._conn:
            for t in ["provenance","policy","posture","revocations","decision_cache","decisions","events"]:
                self._conn.execute(f"DELETE FROM {t}")
            self._conn.execute("UPDATE state SET value='1' WHERE key='evidence_version'")

    def _bump(self):
        v = int(self.get_state("evidence_version") or "1") + 1
        self._conn.execute("UPDATE state SET value=? WHERE key='evidence_version'", (str(v),))
        self._conn.execute("DELETE FROM decision_cache")
        return str(v)

    def get_state(self, key: str) -> str | None:
        r = self._conn.execute("SELECT value FROM state WHERE key=?", (key,)).fetchone()
        return r[0] if r else None

    def put_provenance(self, digest: str, envelope: dict, signature: str, expires_at: float, signer_id: str):
        with self._lock, self._conn:
            self._conn.execute("REPLACE INTO provenance VALUES(?,?,?,?,?,?,0)", (digest,json.dumps(envelope),signature,time.time(),expires_at,signer_id))
            self._bump()
            self.event("provenance_upsert", digest, {"signer_id": signer_id})

    def get_provenance(self, digest: str):
        r = self._conn.execute("SELECT * FROM provenance WHERE artifact_digest=?", (digest,)).fetchone()
        return dict(r) if r else None

    def put_policy(self, resource: str, action: str, policy: dict, version: str):
        with self._lock, self._conn:
            self._conn.execute("REPLACE INTO policy VALUES(?,?,?,?,?)", (resource,action,json.dumps(policy),version,time.time()))
            self._bump(); self.event("policy_upsert", f"{resource}:{action}", {"version":version})

    def get_policy(self, resource: str, action: str):
        r = self._conn.execute("SELECT * FROM policy WHERE resource=? AND action=?", (resource,action)).fetchone()
        return dict(r) if r else None

    def put_posture(self, workload_id: str, posture: dict, expires_at: float):
        with self._lock, self._conn:
            self._conn.execute("REPLACE INTO posture VALUES(?,?,?,?)", (workload_id,json.dumps(posture),time.time(),expires_at))
            self._bump(); self.event("posture_upsert", workload_id, posture)

    def get_posture(self, workload_id: str):
        r = self._conn.execute("SELECT * FROM posture WHERE workload_id=?", (workload_id,)).fetchone()
        return dict(r) if r else None

    def revoke(self, kind: str, subject: str, reason: str):
        with self._lock, self._conn:
            self._conn.execute("REPLACE INTO revocations VALUES(?,?,?,?)", (kind,subject,reason,time.time()))
            if kind == "artifact": self._conn.execute("UPDATE provenance SET revoked=1 WHERE artifact_digest=?", (subject,))
            self._bump(); self.event("revocation", f"{kind}:{subject}", {"reason":reason})

    def is_revoked(self, kind: str, subject: str) -> bool:
        return self._conn.execute("SELECT 1 FROM revocations WHERE kind=? AND subject=?", (kind,subject)).fetchone() is not None

    def cache_get(self, key: str):
        r = self._conn.execute("SELECT * FROM decision_cache WHERE cache_key=?", (key,)).fetchone()
        if not r: return None
        d = dict(r)
        if d["expires_at"] < time.time() or d["evidence_version"] != self.get_state("evidence_version"):
            with self._conn: self._conn.execute("DELETE FROM decision_cache WHERE cache_key=?", (key,))
            return None
        return json.loads(d["response_json"])

    def cache_put(self, key: str, response: dict, ttl: int):
        with self._conn:
            self._conn.execute("REPLACE INTO decision_cache VALUES(?,?,?,?,?)", (key,json.dumps(response),time.time(),time.time()+ttl,self.get_state("evidence_version")))

    def decision_put(self, request_id: str, response: dict):
        with self._conn:
            self._conn.execute("REPLACE INTO decisions VALUES(?,?,?)", (request_id,time.time(),json.dumps(response)))

    def decision_get(self, request_id: str):
        r = self._conn.execute("SELECT response_json FROM decisions WHERE request_id=?", (request_id,)).fetchone()
        return json.loads(r[0]) if r else None

    def event(self, event_type: str, subject: str, details: dict):
        self._conn.execute("INSERT INTO events(ts,event_type,subject,details_json) VALUES(?,?,?,?)", (time.time(),event_type,subject,json.dumps(details)))

    def events(self, limit: int = 100):
        rows = self._conn.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(x) for x in rows]
