from __future__ import annotations
import argparse, hashlib, json
from .runtime import store
from .admin import create_provenance, issue_identity, upsert_policy, upsert_posture

GOOD_ARTIFACT = "sha256:" + hashlib.sha256(b"payments-api:v1").hexdigest()
BAD_ARTIFACT = "sha256:" + hashlib.sha256(b"payments-api:tampered").hexdigest()

def seed(reset=False):
    if reset: store.reset()
    create_provenance(GOOD_ARTIFACT)
    upsert_policy()
    upsert_posture()
    token=issue_identity("payments-api","prod.example",GOOD_ARTIFACT,["secret:read"])
    out={"good_artifact":GOOD_ARTIFACT,"bad_artifact":BAD_ARTIFACT,"identity_token":token,"resource":"secret://payments/db","action":"read"}
    print(json.dumps(out,indent=2))
    return out

if __name__ == "__main__":
    p=argparse.ArgumentParser(); p.add_argument("--reset",action="store_true")
    args=p.parse_args(); seed(args.reset)
