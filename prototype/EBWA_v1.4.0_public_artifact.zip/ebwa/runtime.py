from __future__ import annotations
from .settings import DB_PATH, KEY_DIR
from .crypto import ensure_keypair
from .store import Store
from .engine import EBWAEngine

IDENTITY_PRIVATE = KEY_DIR / "identity_private.pem"
IDENTITY_PUBLIC = KEY_DIR / "identity_public.pem"
PROV_PRIVATE = KEY_DIR / "provenance_private.pem"
PROV_PUBLIC = KEY_DIR / "provenance_public.pem"
ensure_keypair(IDENTITY_PRIVATE, IDENTITY_PUBLIC)
ensure_keypair(PROV_PRIVATE, PROV_PUBLIC)
store = Store(DB_PATH)
engine = EBWAEngine(store, IDENTITY_PUBLIC, PROV_PUBLIC)
