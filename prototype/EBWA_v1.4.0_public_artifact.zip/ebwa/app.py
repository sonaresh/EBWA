from __future__ import annotations
import time
from fastapi import FastAPI, Header, HTTPException
from .models import *
from .runtime import store, engine
from .admin import issue_identity, create_provenance, upsert_policy, upsert_posture
from .settings import ADMIN_TOKEN

app=FastAPI(title="EBWA Gateway",version="1.0.0")

def admin_guard(x_ebwa_admin: str|None):
    if x_ebwa_admin != ADMIN_TOKEN: raise HTTPException(401,"invalid admin token")

@app.get("/health")
def health(): return {"status":"ok","evidence_version":store.get_state("evidence_version")}

@app.post("/v1/authorize",response_model=AuthorizationResponse)
def authorize(req:AuthorizationRequest): return engine.authorize(req)

@app.post("/v1/admin/identity")
def identity(req:IdentityIssueRequest,x_ebwa_admin:str|None=Header(default=None)):
    admin_guard(x_ebwa_admin); return {"token":issue_identity(req.workload_id,req.trust_domain,req.artifact_digest,req.scopes,req.ttl_seconds)}

@app.post("/v1/admin/provenance")
def provenance(req:ProvenanceCreateRequest,x_ebwa_admin:str|None=Header(default=None)):
    admin_guard(x_ebwa_admin); return create_provenance(req.artifact_digest,req.source_repo,req.commit_sha,req.builder_id,req.slsa_level,req.ttl_seconds)

@app.post("/v1/admin/policy")
def policy(req:PolicyUpsertRequest,x_ebwa_admin:str|None=Header(default=None)):
    admin_guard(x_ebwa_admin); return upsert_policy(req.resource,req.action,req.allowed_trust_domains,req.required_scope,req.require_fresh,req.require_isolation,req.version)

@app.post("/v1/admin/posture")
def posture(req:PostureUpsertRequest,x_ebwa_admin:str|None=Header(default=None)):
    admin_guard(x_ebwa_admin); return upsert_posture(req.workload_id,req.healthy,req.isolation_ok,req.telemetry_ok,req.ttl_seconds,req.reason)

@app.post("/v1/admin/revoke")
def revoke(req:RevocationRequest,x_ebwa_admin:str|None=Header(default=None)):
    admin_guard(x_ebwa_admin); store.revoke(req.kind,req.subject,req.reason); return {"ok":True}

@app.post("/v1/admin/planes/{plane}/{state}")
def plane(plane:str,state:str,x_ebwa_admin:str|None=Header(default=None)):
    admin_guard(x_ebwa_admin)
    if plane not in {"identity","provenance","policy","posture"} or state not in {"up","down"}: raise HTTPException(400,"invalid plane/state")
    setattr(engine,f"{plane}_plane_available",state=="up"); store.event("plane_state",plane,{"state":state}); return {plane:state}

@app.get("/v1/events")
def events(limit:int=100): return store.events(limit)
