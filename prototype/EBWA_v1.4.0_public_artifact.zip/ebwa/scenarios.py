from __future__ import annotations
import hashlib, time, uuid
from dataclasses import dataclass
from .runtime import store, engine
from .admin import issue_identity, create_provenance, upsert_policy, upsert_posture
from .models import AuthorizationRequest

GOOD="sha256:"+hashlib.sha256(b"payments-api:v1").hexdigest()
BAD="sha256:"+hashlib.sha256(b"payments-api:tampered").hexdigest()
RESOURCE="secret://payments/db"; ACTION="read"

@dataclass
class Scenario:
    id:str; name:str; attack_family:str; expected_full:str; setup:str

SCENARIOS=[
Scenario("S01","Legitimate workload","normal","ALLOW","normal"),
Scenario("S02","Artifact substitution with valid identity","supply-chain","DENY","artifact_substitution"),
Scenario("S03","Unsigned artifact","supply-chain","DENY","unsigned_artifact"),
Scenario("S04","Stolen credential used with different artifact","credential","DENY","stolen_credential"),
Scenario("S05","Policy revocation after admission","policy-drift","DENY","policy_drift"),
Scenario("S06","Runtime posture degradation","runtime-drift","DENY","posture_drift"),
Scenario("S07","Isolation degradation","runtime-isolation","DENY_E_ONLY","isolation_drift"),
Scenario("S08","Wrong trust domain lateral movement","lateral-movement","DENY","wrong_domain"),
Scenario("S09","Insufficient scope","privilege","DENY","wrong_scope"),
Scenario("S10","Expired workload identity","identity","DENY","expired_identity"),
Scenario("S11","Revoked workload identity","identity","REVOKE","revoked_identity"),
Scenario("S12","Revoked provenance signer","supply-chain","REVOKE","revoked_signer"),
Scenario("S13","Stale provenance","supply-chain","DENY","stale_provenance"),
Scenario("S14","Stale posture","runtime-drift","DENY","stale_posture"),
Scenario("S15","Provenance service outage","control-plane","DENY","prov_outage"),
Scenario("S16","Posture service outage","control-plane","DENY","posture_outage"),
Scenario("S17","Policy service outage","control-plane","DENY","policy_outage"),
Scenario("S18","Identity service outage","control-plane","DENY","identity_outage"),
Scenario("S19","Cached allow invalidated by posture change","revocation","DENY","cache_posture_invalidate"),
Scenario("S20","Cached allow invalidated by policy change","revocation","DENY","cache_policy_invalidate"),
]

def base_state():
    store.reset(); engine.identity_plane_available=engine.provenance_plane_available=engine.policy_plane_available=engine.posture_plane_available=True
    create_provenance(GOOD); upsert_policy(); upsert_posture()
    return issue_identity("payments-api","prod.example",GOOD,["secret:read"])

def run_scenario(s:Scenario, config:str):
    token=base_state(); artifact=GOOD
    st=s.setup
    if st=="artifact_substitution": artifact=BAD; create_provenance(BAD)
    elif st=="unsigned_artifact": artifact=BAD
    elif st=="stolen_credential": artifact=BAD; create_provenance(BAD)
    elif st=="policy_drift": upsert_policy(domains=["other.example"],version="v2")
    elif st=="posture_drift": upsert_posture(healthy=False,reason="runtime drift")
    elif st=="isolation_drift": upsert_posture(isolation_ok=False,reason="isolation degraded")
    elif st=="wrong_domain": token=issue_identity("payments-api","dev.example",GOOD,["secret:read"])
    elif st=="wrong_scope": token=issue_identity("payments-api","prod.example",GOOD,["metrics:read"])
    elif st=="expired_identity": token=issue_identity("payments-api","prod.example",GOOD,["secret:read"],ttl=-1)
    elif st=="revoked_identity":
        import jwt as _jwt
        claims=_jwt.decode(token,options={"verify_signature":False}); store.revoke("identity",claims["jti"],"test")
    elif st=="revoked_signer": store.revoke("signer","builder://ebwa-lab","test")
    elif st=="stale_provenance": create_provenance(GOOD,ttl=-1)
    elif st=="stale_posture": upsert_posture(ttl=-1)
    elif st=="prov_outage": engine.provenance_plane_available=False
    elif st=="posture_outage": engine.posture_plane_available=False
    elif st=="policy_outage": engine.policy_plane_available=False
    elif st=="identity_outage": engine.identity_plane_available=False
    elif st=="cache_posture_invalidate":
        r1=engine.authorize(AuthorizationRequest(identity_token=token,artifact_digest=GOOD,resource=RESOURCE,action=ACTION,config=config,request_id=str(uuid.uuid4())))
        upsert_posture(healthy=False,reason="drift after cache")
    elif st=="cache_policy_invalidate":
        r1=engine.authorize(AuthorizationRequest(identity_token=token,artifact_digest=GOOD,resource=RESOURCE,action=ACTION,config=config,request_id=str(uuid.uuid4())))
        upsert_policy(domains=["other.example"],version="v2")
    req=AuthorizationRequest(identity_token=token,artifact_digest=artifact,resource=RESOURCE,action=ACTION,config=config,request_id=str(uuid.uuid4()))
    return engine.authorize(req)
