from __future__ import annotations
import time
from .crypto import issue_identity_token, sign_object
from .settings import IDENTITY_ISSUER
from .runtime import store, IDENTITY_PRIVATE, PROV_PRIVATE


def issue_identity(workload_id: str, trust_domain: str, artifact_digest: str, scopes: list[str], ttl: int=300) -> str:
    return issue_identity_token({"sub":workload_id,"trust_domain":trust_domain,"artifact_digest":artifact_digest,"scopes":scopes}, IDENTITY_PRIVATE, IDENTITY_ISSUER, ttl)


def create_provenance(artifact_digest: str, source_repo: str="https://example.invalid/repo", commit_sha: str="deadbeef", builder_id: str="builder://ebwa-lab", slsa_level: int=3, ttl: int=3600):
    env = {"predicateType":"https://slsa.dev/provenance/v1","artifact_digest":artifact_digest,"source_repo":source_repo,"commit_sha":commit_sha,"builder_id":builder_id,"slsa_level":slsa_level,"issued_at":time.time()}
    sig = sign_object(env, PROV_PRIVATE)
    store.put_provenance(artifact_digest, env, sig, time.time()+ttl, builder_id)
    return {"envelope":env,"signature":sig}


def upsert_policy(resource="secret://payments/db", action="read", domains=None, scope="secret:read", require_fresh=False, require_isolation=False, version="v1"):
    domains = domains or ["prod.example"]
    p={"resource":resource,"action":action,"allowed_trust_domains":domains,"required_scope":scope,"require_fresh":require_fresh,"require_isolation":require_isolation}
    store.put_policy(resource, action, p, version)
    return p


def upsert_posture(workload_id="payments-api", healthy=True, isolation_ok=True, telemetry_ok=True, ttl=60, reason="healthy"):
    p={"workload_id":workload_id,"healthy":healthy,"isolation_ok":isolation_ok,"telemetry_ok":telemetry_ok,"reason":reason}
    store.put_posture(workload_id,p,time.time()+ttl)
    return p
