from __future__ import annotations
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = Path(os.getenv("EBWA_DATA_DIR", ROOT / ".data"))
DB_PATH = Path(os.getenv("EBWA_DB_PATH", DATA_DIR / "ebwa.db"))
KEY_DIR = Path(os.getenv("EBWA_KEY_DIR", DATA_DIR / "keys"))
ADMIN_TOKEN = os.getenv("EBWA_ADMIN_TOKEN", "ebwa-lab-admin")
IDENTITY_ISSUER = os.getenv("EBWA_IDENTITY_ISSUER", "ebwa://lab-identity")
DEFAULT_IDENTITY_TTL = int(os.getenv("EBWA_IDENTITY_TTL", "300"))
DEFAULT_PROVENANCE_TTL = int(os.getenv("EBWA_PROVENANCE_TTL", "3600"))
DEFAULT_POSTURE_TTL = int(os.getenv("EBWA_POSTURE_TTL", "60"))
DEFAULT_DECISION_TTL = int(os.getenv("EBWA_DECISION_TTL", "10"))
