# EBWA End-to-End Prototype v1.2.1

Reference implementation and benchmark harness for **Evidence-Bound Workload Authorization (EBWA)** from the manuscript *Closing the Attestation-to-Authorization Gap: Evidence-Bound Workload Authorization for Enterprise Multi-Cloud Platforms*.

EBWA enforces one runtime invariant:

> A protected action is authorized only when workload identity, the exact executing artifact, verified provenance, applicable policy, and current posture are all valid and bound to the authorization decision.

## What v1.2.1 validates

- Ed25519-signed workload identity tokens.
- Ed25519-signed provenance attestations bound to SHA-256 artifact digests.
- SQLite-backed provenance, policy, posture, revocation, decision-cache, and audit state.
- Five ablation configurations:
  - **A** — native identity + policy baseline
  - **B** — identity + exact artifact binding + policy
  - **C** — identity + provenance + policy, without identity-artifact runtime binding
  - **D** — full EBWA: identity + exact artifact + provenance + policy + posture
  - **E** — full EBWA + strong-isolation predicate
- Configuration-specific evidence resolution so an ablation does not pay for controls it does not evaluate.
- Evidence freshness, TTLs, revocation, cache invalidation, and evidence-plane outage behavior.
- 20 deterministic attack/failure scenarios across all five configurations.
- Controlled EBWA-Bench performance methodology with paired logical requests, randomized configuration order, excluded warm-up rounds, independent trials, fresh and cached modes, raw per-request traces, confidence intervals, and drift/revocation measurements.
- Real scale corpus instantiation: workload identities/posture objects, provenance objects, policy objects, and trust domains increase with `--scale`.
- EBAR, NDE, paired SDO95, p50/p95/p99 latency, cache-hit rate, revocation delay, CPU time, and Python allocator peak memory.
- FastAPI gateway + protected-resource demonstration.
- Docker Compose and two-kind-cluster deployment assets.

## Scientific boundary

Measurements are valid only for the machine/environment on which they were generated. The repository intentionally ships without benchmark results, generated keys, or runtime databases. Freeze the software version and archive the generated evidence before using numerical results in the manuscript.

Do not interpret a small local benchmark as an enterprise production benchmark. Enterprise-scale claims require the frozen multi-trial runs plus multi-cluster and external-environment validation described in `research/EXPERIMENT_PLAN.md`.

## Windows PowerShell setup

```powershell
cd EBWA_End_to_End_Prototype_v1.2.1

py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install -e .
```

Verify installation:

```powershell
python -c "import ebwa; print(ebwa.__file__)"
```

## Phase 1 — core validation

```powershell
python -m ebwa.seed --reset
python -m pytest -q
```

Expected baseline: all tests pass.

## Phase 2 — security scenario corpus

```powershell
python -m ebwa.scenario_runner --all --output evidence\scenarios.json
```

The scenario runner executes 20 scenarios across A–E and writes 100 configuration-scenario outcomes.

## Phase 3 — controlled EBWA-Bench

Recommended first controlled run:

```powershell
python -m ebwa.benchmark `
  --repetitions 1000 `
  --trials 5 `
  --warmup 100 `
  --scale 1000 `
  --drift-events 20 `
  --mode both `
  --output-dir evidence\benchmark-v1.1
```

The benchmark now uses the same logical workload for A–E within each paired round, randomizes configuration execution order, excludes warm-up rounds, and separately measures:

- `fresh` — synchronous evidence evaluation (`force_fresh=True`)
- `cached` — pre-warmed bounded decision-cache behavior

### Outputs

`evidence\benchmark-v1.1\summary.json`
: full machine-readable experiment summary.

`evidence\benchmark-v1.1\latency_summary.csv`
: per-mode/configuration p50/p95/p99, cache-hit rate, EBAR, and trial-level p95 confidence interval.

`evidence\benchmark-v1.1\raw_latency.csv`
: every measured authorization decision with mode, trial, paired round, execution order, workload, latency, cache status, and decision.

`evidence\benchmark-v1.1\drift_results.csv`
: per-event stale-trust/revocation propagation observations.

### Metric interpretation

- **EBAR** is meaningful for full evidence binding (D/E). A–C intentionally do not bind all five EBWA evidence domains, so their strict EBAR is expected to be 0 even if their narrower control predicates pass.
- **SDO95_paired_ms** is the p95 of latency deltas `D - A` for matched logical requests. This is now a true paired comparison.
- **p95_difference_D_minus_A_ms** separately reports aggregate `p95(D) - p95(A)` and should not be confused with paired SDO95.
- **NDE** is computed from measured drift windows and the drift experiment observation window.
- `peak_python_memory_mb` is Python allocator peak measured by `tracemalloc`, not host RSS.

## Scale progression for manuscript evidence

Do not jump directly to the largest run. Freeze one level at a time:

```powershell
# S1
python -m ebwa.benchmark --repetitions 1000 --trials 5 --warmup 100 --scale 1000 --mode both --output-dir evidence\scale-1k

# S2
python -m ebwa.benchmark --repetitions 2000 --trials 5 --warmup 200 --scale 10000 --mode both --output-dir evidence\scale-10k
```

For 50k/100k logical identities, first validate runtime and storage cost on the lab machine; provenance and policy object counts are deliberately bounded while workload/posture objects continue to scale.

## Live end-to-end API demonstration

Terminal 1:

```powershell
.\.venv\Scripts\Activate.ps1
uvicorn ebwa.app:app --host 127.0.0.1 --port 8000
```

Terminal 2:

```powershell
.\.venv\Scripts\Activate.ps1
$env:EBWA_GATEWAY_URL="http://127.0.0.1:8000"
uvicorn ebwa.resource_app:app --host 127.0.0.1 --port 8001
```

Terminal 3:

```powershell
.\.venv\Scripts\Activate.ps1
python scripts\live_demo.py
```

The demonstration shows valid EBWA authorization, artifact substitution denial, and cache invalidation after runtime posture drift.

## Docker Compose

```powershell
docker compose up --build -d
python scripts\live_demo.py --gateway http://127.0.0.1:8000 --resource http://127.0.0.1:8001
docker compose down -v
```

## Multi-cluster validation with kind

Prerequisites: Docker, `kubectl`, and `kind`.

```powershell
powershell -ExecutionPolicy Bypass -File scripts\kind-up.ps1
powershell -ExecutionPolicy Bypass -File scripts\kind-smoke.ps1
powershell -ExecutionPolicy Bypass -File scripts\kind-down.ps1
```

## GitHub safety

The supplied `.gitignore` excludes generated private keys, runtime databases, virtual environments, and experiment outputs. Never commit `.data/`, private PEM files, cloud credentials, or raw secrets.

## Research workflow

See:

- `research/EXPERIMENT_PLAN.md`
- `research/MANUSCRIPT_MAPPING.md`
- `research/SCENARIO_MAP.csv`


## Benchmark v1.2 methodology

`ebwa.benchmark` now separates three profiles:

- `fresh`: synchronous evidence evaluation, no decision-cache use.
- `cached-high-reuse`: bounded hot working set (default 32 workloads), designed to characterize the upper-benefit case for cached evidence-bound authorization.
- `cached-large-working-set`: samples the complete logical enterprise workload population to characterize cache behavior under broader cardinality.

Per-configuration serial throughput is computed from wall-clock time spent inside that configuration's measured `authorize()` calls. It is intentionally labeled **serial throughput** and must not be reported as concurrent service capacity. Final publication-scale throughput should additionally use a concurrent external load generator.

NDE uses a declared fixed normalization window per event (`--drift-window-s`, default 1.0 s), while raw revocation latency p50/p95/p99 is retained as the primary drift result.

Progress is printed to stderr during long trials.

### Recommended verification run

```powershell
python -m ebwa.benchmark `
  --repetitions 1000 `
  --trials 5 `
  --warmup 100 `
  --scale 1000 `
  --drift-events 50 `
  --mode both `
  --cache-profile both `
  --output-dir evidence\benchmark-v1.2-verify
```

Before moving to 10k logical scale, verify that configuration throughput values differ, `cached-high-reuse` has a high cache-hit rate, and `benchmark_version` is `1.2.0`.


## v1.2.1 long-run reliability fix

Long publication runs can exceed the original one-hour provenance/posture TTL. v1.2.1 uses an explicit benchmark-only evidence TTL (`--evidence-ttl-s`, default 86400 seconds) so wall-clock expiration does not contaminate performance measurements. Drift and revocation are still injected explicitly by the benchmark.

Each completed profile now writes a checkpoint JSON immediately. Long runs therefore preserve completed fresh/high-reuse results if a later profile fails.

To recover completed trials from a v1.2.0 interrupted run:

```powershell
python -m ebwa.recover_benchmark `
  --raw evidence\benchmark-v1.2-scale10k-final\raw_latency.csv `
  --expected-repetitions 5000 `
  --output evidence\benchmark-v1.2-scale10k-final\recovered-summary.json
```

To complete only the large-working-set profile without repeating fresh/high-reuse:

```powershell
python -m ebwa.benchmark `
  --repetitions 5000 `
  --trials 10 `
  --warmup 500 `
  --scale 10000 `
  --drift-events 200 `
  --mode cached `
  --cache-profile large-working-set `
  --evidence-ttl-s 86400 `
  --output-dir evidence\benchmark-v1.2.1-scale10k-large-final
```

## v1.3 two-cluster kind validation

v1.3 adds an evidence-producing two-cluster security validation. Cluster A uses trust domain `prod.us-east`; cluster B uses `prod.us-west`. Each gateway has an independent local signing root.

Prerequisites:

```powershell
docker version
kind version
kubectl version --client
```

Create both clusters and deploy EBWA:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\kind-up.ps1
```

Run health checks plus the security validation:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\kind-run-validation.ps1
```

Expected result: `11/11 tests passed` (K09 has separate D and E assertions). Evidence is written to `evidence\kind-v1.3\summary.json` and `results.csv`.

Clean up when finished:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\kind-down.ps1
```

See `research/KIND_MULTI_CLUSTER_PLAN.md` for experiment semantics and interpretation limits.

---

## AWS EKS external validation (v1.4.0)

v1.4.0 adds a short-lived AWS EKS experiment to validate EBWA outside the local Docker/kind environment.

Prerequisites: AWS CLI v2, Docker Desktop, `kubectl`, `eksctl`, Python environment installed from this repository, and an AWS principal that can create EKS, CloudFormation, EC2/VPC, IAM, and ECR resources.

Create the lab:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\aws-up.ps1 -Profile <YOUR_AWS_PROFILE> -Region us-east-2
```

Run the external validation:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\aws-run-validation.ps1 -Profile <YOUR_AWS_PROFILE> -Region us-east-2 -PerfRepetitions 500
```

Collect evidence **before teardown**:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\aws-collect-evidence.ps1 -Profile <YOUR_AWS_PROFILE> -Region us-east-2
```

Delete the EKS cluster as soon as evidence collection is complete:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\aws-down.ps1 -Profile <YOUR_AWS_PROFILE> -Region us-east-2
```

To also remove the two ECR repositories:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\aws-down.ps1 -Profile <YOUR_AWS_PROFILE> -Region us-east-2 -DeleteEcrRepositories
```

See `research/AWS_EXTERNAL_VALIDATION_PLAN.md` for experiment boundaries and manuscript-safe interpretation.
