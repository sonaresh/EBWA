import hashlib, uuid, time, jwt
from ebwa.runtime import store, engine
from ebwa.admin import create_provenance, issue_identity, upsert_policy, upsert_posture
from ebwa.models import AuthorizationRequest

GOOD="sha256:"+hashlib.sha256(b"x").hexdigest(); BAD="sha256:"+hashlib.sha256(b"bad").hexdigest(); R="secret://payments/db"; A="read"

def setup():
    store.reset(); engine.identity_plane_available=engine.provenance_plane_available=engine.policy_plane_available=engine.posture_plane_available=True
    create_provenance(GOOD); upsert_policy(R,A,["prod.example"],"secret:read"); upsert_posture("w1")
    return issue_identity("w1","prod.example",GOOD,["secret:read"])

def auth(token,digest=GOOD,config="D",force=True):
    return engine.authorize(AuthorizationRequest(identity_token=token,artifact_digest=digest,resource=R,action=A,config=config,request_id=str(uuid.uuid4()),force_fresh=force))

def test_full_allow(): assert auth(setup()).decision=="ALLOW"
def test_artifact_substitution_denied_full():
    t=setup(); create_provenance(BAD); assert auth(t,BAD,"D").decision=="DENY"
def test_native_baseline_misses_artifact_substitution():
    t=setup(); create_provenance(BAD); assert auth(t,BAD,"A").decision=="ALLOW"
def test_provenance_only_can_miss_identity_artifact_binding():
    t=setup(); create_provenance(BAD); assert auth(t,BAD,"C").decision=="ALLOW"
def test_posture_drift_denied():
    t=setup(); upsert_posture("w1",healthy=False); assert auth(t).decision=="DENY"
def test_policy_drift_denied():
    t=setup(); upsert_policy(R,A,["other.example"],"secret:read",version="v2"); assert auth(t).decision=="DENY"
def test_wrong_scope_denied():
    setup(); t=issue_identity("w1","prod.example",GOOD,["metrics:read"]); assert auth(t).decision=="DENY"
def test_wrong_domain_denied():
    setup(); t=issue_identity("w1","dev.example",GOOD,["secret:read"]); assert auth(t).decision=="DENY"
def test_revoked_workload_denied():
    t=setup(); store.revoke("workload","w1","test"); assert auth(t).decision in {"DENY","REVOKE"}
def test_revoked_signer_denied():
    t=setup(); store.revoke("signer","builder://ebwa-lab","test"); assert auth(t).decision in {"DENY","REVOKE"}
def test_provenance_outage_denied_full():
    t=setup(); engine.provenance_plane_available=False; assert auth(t).decision=="DENY"
def test_identity_outage_denied_full():
    t=setup(); engine.identity_plane_available=False; assert auth(t).decision=="DENY"
def test_isolation_only_required_in_e():
    t=setup(); upsert_posture("w1",isolation_ok=False); assert auth(t,config="D").decision=="ALLOW"; assert auth(t,config="E").decision=="DENY"
def test_idempotent_request():
    t=setup(); rid=str(uuid.uuid4()); req=AuthorizationRequest(identity_token=t,artifact_digest=GOOD,resource=R,action=A,config="D",request_id=rid); a=engine.authorize(req); b=engine.authorize(req); assert a.decision==b.decision=="ALLOW"
def test_cache_invalidated_on_posture_update():
    t=setup(); a=auth(t,force=False); assert a.decision=="ALLOW"; upsert_posture("w1",healthy=False); b=auth(t,force=False); assert b.decision=="DENY"


def test_package_version_v140():
    import ebwa
    assert ebwa.__version__ == "1.4.0"

