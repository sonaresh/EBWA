param(
  [Parameter(Mandatory=$true)][string]$Profile,
  [string]$Region = "us-east-2",
  [string]$ClusterName = "ebwa-external-v14",
  [int]$PerfRepetitions = 500
)
$ErrorActionPreference = "Stop"
$env:AWS_PROFILE = $Profile
$env:AWS_REGION = $Region
$Context = (kubectl config get-contexts -o name | Where-Object { $_ -like "*$ClusterName*" } | Select-Object -First 1)
if (-not $Context) { throw "Could not resolve kubectl context for $ClusterName" }

Write-Host "[aws] checking workload health"
kubectl --context $Context -n ebwa-east get pods,svc -o wide
kubectl --context $Context -n ebwa-west get pods,svc -o wide

python scripts\aws_validate.py `
  --context $Context `
  --namespace-a ebwa-east `
  --namespace-b ebwa-west `
  --trust-domain-a aws.prod.us-east `
  --trust-domain-b aws.prod.us-west `
  --perf-repetitions $PerfRepetitions `
  --output-dir evidence\aws-v1.4
