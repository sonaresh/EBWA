param(
  [Parameter(Mandatory=$true)][string]$Profile,
  [string]$Region = "us-east-2",
  [string]$ClusterName = "ebwa-external-v14",
  [switch]$DeleteEcrRepositories
)
$ErrorActionPreference = "Stop"
$env:AWS_PROFILE = $Profile
$env:AWS_REGION = $Region

Write-Host "[aws] deleting EKS cluster $ClusterName"
eksctl delete cluster --name $ClusterName --region $Region --profile $Profile --wait

if ($DeleteEcrRepositories) {
  foreach ($repo in @("ebwa-gateway", "ebwa-resource")) {
    aws ecr delete-repository --repository-name $repo --force --region $Region --profile $Profile 2>$null | Out-Null
    Write-Host "[aws] deleted ECR repository $repo"
  }
}
Write-Host "[aws] teardown complete"
