from __future__ import annotations
import argparse,hashlib,json,uuid,httpx,time
ADMIN={"x-ebwa-admin":"ebwa-lab-admin"}
GOOD="sha256:"+hashlib.sha256(b"payments-api:v1").hexdigest(); BAD="sha256:"+hashlib.sha256(b"payments-api:tampered").hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument("--gateway",default="http://127.0.0.1:8000");p.add_argument("--resource",default="http://127.0.0.1:8001");args=p.parse_args();g=args.gateway
    httpx.post(g+"/v1/admin/provenance",headers=ADMIN,json={"artifact_digest":GOOD,"source_repo":"https://example.invalid/repo","commit_sha":"abc123","builder_id":"builder://ebwa-lab","slsa_level":3,"ttl_seconds":3600}).raise_for_status()
    httpx.post(g+"/v1/admin/policy",headers=ADMIN,json={"resource":"secret://payments/db","action":"read","allowed_trust_domains":["prod.example"],"required_scope":"secret:read","require_fresh":False,"require_isolation":False,"version":"v1"}).raise_for_status()
    httpx.post(g+"/v1/admin/posture",headers=ADMIN,json={"workload_id":"payments-api","healthy":True,"isolation_ok":True,"telemetry_ok":True,"ttl_seconds":60,"reason":"healthy"}).raise_for_status()
    token=httpx.post(g+"/v1/admin/identity",headers=ADMIN,json={"workload_id":"payments-api","trust_domain":"prod.example","artifact_digest":GOOD,"scopes":["secret:read"],"ttl_seconds":300}).json()["token"]
    auth={"Authorization":"Bearer "+token}
    ok=httpx.post(args.resource+"/v1/secret",headers=auth,json={"artifact_digest":GOOD,"config":"D"});print("1 legitimate:",ok.status_code,ok.json())
    bad=httpx.post(args.resource+"/v1/secret",headers=auth,json={"artifact_digest":BAD,"config":"D"});print("2 artifact substitution:",bad.status_code,bad.json())
    httpx.post(g+"/v1/admin/posture",headers=ADMIN,json={"workload_id":"payments-api","healthy":False,"isolation_ok":True,"telemetry_ok":True,"ttl_seconds":60,"reason":"runtime drift"}).raise_for_status()
    drift=httpx.post(args.resource+"/v1/secret",headers=auth,json={"artifact_digest":GOOD,"config":"D"});print("3 posture drift:",drift.status_code,drift.json())

if __name__=="__main__":main()
