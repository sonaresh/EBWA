from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import subprocess
import sys
import time
import uuid
from contextlib import ExitStack
from pathlib import Path

import httpx

ADMIN_TOKEN = os.getenv("EBWA_ADMIN_TOKEN", "ebwa-lab-admin")
ADMIN = {"x-ebwa-admin": ADMIN_TOKEN}
RESOURCE = "secret://payments/db"
ACTION = "read"
GOOD = "sha256:" + hashlib.sha256(b"payments-api:v1").hexdigest()
BAD = "sha256:" + hashlib.sha256(b"payments-api:tampered").hexdigest()


def wait_http(url: str, timeout: float = 30.0) -> None:
    end = time.time() + timeout
    last = None
    while time.time() < end:
        try:
            r = httpx.get(url, timeout=2)
            if r.status_code == 200:
                return
            last = f"HTTP {r.status_code}"
        except Exception as exc:  # pragma: no cover - depends on local kubectl timing
            last = type(exc).__name__
        time.sleep(0.5)
    raise RuntimeError(f"timed out waiting for {url}: {last}")


def start_port_forward(context: str, service: str, local_port: int, remote_port: int) -> subprocess.Popen:
    cmd = [
        "kubectl", "--context", context, "-n", "ebwa", "port-forward",
        f"service/{service}", f"{local_port}:{remote_port}", "--address", "127.0.0.1",
    ]
    # Suppress routine forwarding chatter; errors are surfaced if the endpoint never becomes healthy.
    return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def post(url: str, path: str, payload: dict, admin: bool = False) -> httpx.Response:
    return httpx.post(url + path, headers=ADMIN if admin else None, json=payload, timeout=10)


def seed_cluster(gateway: str, trust_domain: str, workload_id: str = "payments-api") -> str:
    for path, payload in [
        ("/v1/admin/provenance", {
            "artifact_digest": GOOD,
            "source_repo": "https://example.invalid/ebwa-kind",
            "commit_sha": "kind-v1",
            "builder_id": f"builder://{trust_domain}",
            "slsa_level": 3,
            "ttl_seconds": 7200,
        }),
        ("/v1/admin/policy", {
            "resource": RESOURCE,
            "action": ACTION,
            "allowed_trust_domains": [trust_domain],
            "required_scope": "secret:read",
            "require_fresh": False,
            "require_isolation": False,
            "version": "kind-v1",
        }),
        ("/v1/admin/posture", {
            "workload_id": workload_id,
            "healthy": True,
            "isolation_ok": True,
            "telemetry_ok": True,
            "ttl_seconds": 7200,
            "reason": "kind healthy",
        }),
    ]:
        r = post(gateway, path, payload, admin=True)
        r.raise_for_status()

    r = post(gateway, "/v1/admin/identity", {
        "workload_id": workload_id,
        "trust_domain": trust_domain,
        "artifact_digest": GOOD,
        "scopes": ["secret:read"],
        "ttl_seconds": 7200,
    }, admin=True)
    r.raise_for_status()
    return r.json()["token"]


def issue_identity(gateway: str, trust_domain: str, artifact: str = GOOD, scopes=None) -> str:
    r = post(gateway, "/v1/admin/identity", {
        "workload_id": "payments-api",
        "trust_domain": trust_domain,
        "artifact_digest": artifact,
        "scopes": scopes if scopes is not None else ["secret:read"],
        "ttl_seconds": 7200,
    }, admin=True)
    r.raise_for_status()
    return r.json()["token"]


def authorize(gateway: str, token: str, artifact: str = GOOD, config: str = "D", force_fresh: bool = True) -> dict:
    r = post(gateway, "/v1/authorize", {
        "identity_token": token,
        "artifact_digest": artifact,
        "resource": RESOURCE,
        "action": ACTION,
        "config": config,
        "request_id": str(uuid.uuid4()),
        "force_fresh": force_fresh,
    })
    r.raise_for_status()
    return r.json()


def set_posture(gateway: str, healthy: bool, isolation_ok: bool = True, reason: str = "test") -> None:
    r = post(gateway, "/v1/admin/posture", {
        "workload_id": "payments-api",
        "healthy": healthy,
        "isolation_ok": isolation_ok,
        "telemetry_ok": True,
        "ttl_seconds": 7200,
        "reason": reason,
    }, admin=True)
    r.raise_for_status()


def set_plane(gateway: str, plane: str, state: str) -> None:
    r = httpx.post(gateway + f"/v1/admin/planes/{plane}/{state}", headers=ADMIN, timeout=10)
    r.raise_for_status()


def resource_call(resource_url: str, token: str, artifact: str = GOOD, config: str = "D") -> tuple[int, dict]:
    r = httpx.post(
        resource_url + "/v1/secret",
        headers={"Authorization": "Bearer " + token},
        json={"artifact_digest": artifact, "config": config},
        timeout=10,
    )
    try:
        body = r.json()
    except Exception:
        body = {"text": r.text}
    return r.status_code, body


def main() -> int:
    ap = argparse.ArgumentParser(description="EBWA two-kind-cluster security validation")
    ap.add_argument("--output-dir", default="evidence/kind-v1.3")
    ap.add_argument("--context-a", default="kind-ebwa-a")
    ap.add_argument("--context-b", default="kind-ebwa-b")
    ap.add_argument("--gateway-a-port", type=int, default=18080)
    ap.add_argument("--gateway-b-port", type=int, default=28080)
    ap.add_argument("--resource-a-port", type=int, default=18081)
    ap.add_argument("--resource-b-port", type=int, default=28081)
    args = ap.parse_args()

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    results: list[dict] = []

    processes = []
    try:
        processes = [
            start_port_forward(args.context_a, "ebwa-gateway", args.gateway_a_port, 8000),
            start_port_forward(args.context_b, "ebwa-gateway", args.gateway_b_port, 8000),
            start_port_forward(args.context_a, "protected-resource", args.resource_a_port, 8001),
            start_port_forward(args.context_b, "protected-resource", args.resource_b_port, 8001),
        ]
        ga = f"http://127.0.0.1:{args.gateway_a_port}"
        gb = f"http://127.0.0.1:{args.gateway_b_port}"
        ra = f"http://127.0.0.1:{args.resource_a_port}"
        rb = f"http://127.0.0.1:{args.resource_b_port}"
        for u in (ga + "/health", gb + "/health", ra + "/health", rb + "/health"):
            wait_http(u)

        print("[kind] seeding cluster A and B")
        token_a = seed_cluster(ga, "prod.us-east")
        token_b = seed_cluster(gb, "prod.us-west")

        def record(name: str, expected: str, observed: str, detail: str, latency_ms: float | None = None):
            ok = expected == observed
            row = {
                "test": name,
                "expected": expected,
                "observed": observed,
                "pass": ok,
                "detail": detail,
                "latency_ms": latency_ms,
            }
            results.append(row)
            print(f"{'PASS' if ok else 'FAIL'} {name}: expected={expected} observed={observed} {detail}")

        # K01/K02: legitimate end-to-end access through each protected resource.
        sc, body = resource_call(ra, token_a)
        record("K01 cluster-A legitimate resource access", "ALLOW", "ALLOW" if sc == 200 else "DENY", f"HTTP {sc}")
        sc, body = resource_call(rb, token_b)
        record("K02 cluster-B legitimate resource access", "ALLOW", "ALLOW" if sc == 200 else "DENY", f"HTTP {sc}")

        # K03: credential minted by cluster A must not authorize in B (independent trust roots).
        r = authorize(gb, token_a)
        record("K03 cross-cluster credential replay A->B", "DENY", r["decision"], r["reason"], r.get("latency_ms"))

        # K04: valid B-signed identity carrying the wrong trust domain must fail B policy.
        wrong_domain_b = issue_identity(gb, "prod.us-east")
        r = authorize(gb, wrong_domain_b)
        record("K04 trust-domain separation in B", "DENY", r["decision"], r["reason"], r.get("latency_ms"))

        # K05: artifact substitution under an otherwise valid cluster-A identity.
        r = authorize(ga, token_a, artifact=BAD)
        record("K05 artifact substitution", "DENY", r["decision"], r["reason"], r.get("latency_ms"))

        # K06: insufficient scope under a correctly signed identity.
        no_scope = issue_identity(ga, "prod.us-east", scopes=["telemetry:read"])
        r = authorize(ga, no_scope)
        record("K06 insufficient scope", "DENY", r["decision"], r["reason"], r.get("latency_ms"))

        # K07: fail closed when provenance plane is unavailable.
        set_plane(ga, "provenance", "down")
        try:
            r = authorize(ga, token_a)
            record("K07 provenance-plane outage fail closed", "DENY", r["decision"], r["reason"], r.get("latency_ms"))
        finally:
            set_plane(ga, "provenance", "up")

        # K08: cached allow must be invalidated after runtime posture degradation.
        set_posture(ga, True, True, "cache warm")
        warm = authorize(ga, token_a, force_fresh=False)
        if warm["decision"] != "ALLOW":
            raise RuntimeError("K08 setup failed: initial cached authorization was not ALLOW")
        set_posture(ga, False, True, "runtime drift")
        r = authorize(ga, token_a, force_fresh=False)
        record("K08 posture drift invalidates cached allow", "DENY", r["decision"], f"cache_hit={r.get('cache_hit')} {r['reason']}", r.get("latency_ms"))
        set_posture(ga, True, True, "restored")

        # K09: E requires isolation while D does not.
        set_posture(ga, True, False, "isolation degraded")
        rd = authorize(ga, token_a, config="D")
        re = authorize(ga, token_a, config="E")
        record("K09a isolation degraded under D", "ALLOW", rd["decision"], rd["reason"], rd.get("latency_ms"))
        record("K09b isolation degraded under E", "DENY", re["decision"], re["reason"], re.get("latency_ms"))
        set_posture(ga, True, True, "restored")

        # K10: protected resource itself must reject tampered artifact.
        sc, body = resource_call(ra, token_a, artifact=BAD)
        record("K10 protected-resource enforcement", "DENY", "DENY" if sc == 403 else "ALLOW", f"HTTP {sc}")

    finally:
        for p in processes:
            try:
                p.terminate()
            except Exception:
                pass
        for p in processes:
            try:
                p.wait(timeout=3)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass

    passed = sum(1 for r in results if r["pass"])
    summary = {
        "validation_version": "1.3.0",
        "timestamp": time.time(),
        "clusters": {
            "A": {"context": args.context_a, "trust_domain": "prod.us-east"},
            "B": {"context": args.context_b, "trust_domain": "prod.us-west"},
        },
        "total_tests": len(results),
        "passed": passed,
        "failed": len(results) - passed,
        "all_passed": passed == len(results),
        "tests": results,
        "interpretation": [
            "K03 tests replay of a credential across independent cluster trust roots.",
            "K04 separately tests policy-level trust-domain separation using a credential signed by the destination cluster.",
            "K08 tests cache invalidation after an evidence-version-changing posture update.",
            "This local kind study is multi-cluster validation, not a public-cloud or production-capacity benchmark.",
        ],
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    with (out / "results.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["test", "expected", "observed", "pass", "detail", "latency_ms"])
        w.writeheader(); w.writerows(results)
    print(f"[done] {passed}/{len(results)} tests passed; evidence written to {out}")
    return 0 if passed == len(results) else 2


if __name__ == "__main__":
    raise SystemExit(main())
