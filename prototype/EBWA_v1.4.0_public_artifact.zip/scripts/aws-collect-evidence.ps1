param(
  [Parameter(Mandatory=$true)][string]$Profile,
  [string]$Region = "us-east-2",
  [string]$ClusterName = "ebwa-external-v14"
)
$ErrorActionPreference = "Stop"
$env:AWS_PROFILE = $Profile
$env:AWS_REGION = $Region
$Context = (kubectl config get-contexts -o name | Where-Object { $_ -like "*$ClusterName*" } | Select-Object -First 1)
if (-not $Context) { throw "Could not resolve kubectl context for $ClusterName" }
$Out = "evidence\aws-v1.4\environment"
New-Item -ItemType Directory -Force $Out | Out-Null

aws sts get-caller-identity --profile $Profile | Out-File "$Out\aws-caller-identity.json"
aws eks describe-cluster --name $ClusterName --region $Region --profile $Profile | Out-File "$Out\eks-cluster.json"
aws eks list-nodegroups --cluster-name $ClusterName --region $Region --profile $Profile | Out-File "$Out\eks-nodegroups.json"
kubectl --context $Context version -o yaml | Out-File "$Out\kubernetes-version.yaml"
kubectl --context $Context get nodes -o wide | Out-File "$Out\nodes.txt"
kubectl --context $Context -n ebwa-east get all -o wide | Out-File "$Out\ebwa-east-workloads.txt"
kubectl --context $Context -n ebwa-west get all -o wide | Out-File "$Out\ebwa-west-workloads.txt"
kubectl --context $Context -n ebwa-east get deployment ebwa-gateway protected-resource -o yaml | Out-File "$Out\ebwa-east-deployments.yaml"
kubectl --context $Context -n ebwa-west get deployment ebwa-gateway protected-resource -o yaml | Out-File "$Out\ebwa-west-deployments.yaml"
kubectl --context $Context -n ebwa-east logs deployment/ebwa-gateway | Out-File "$Out\ebwa-east-gateway.log"
kubectl --context $Context -n ebwa-west logs deployment/ebwa-gateway | Out-File "$Out\ebwa-west-gateway.log"
kubectl --context $Context -n ebwa-east logs deployment/protected-resource | Out-File "$Out\ebwa-east-resource.log"
kubectl --context $Context -n ebwa-west logs deployment/protected-resource | Out-File "$Out\ebwa-west-resource.log"
docker version | Out-File "$Out\docker-version.txt"
aws --version 2>&1 | Out-File "$Out\aws-cli-version.txt"
eksctl version | Out-File "$Out\eksctl-version.txt"

$Archive = "evidence\EBWA-AWS-v1.4-evidence.zip"
Compress-Archive -Path evidence\aws-v1.4\* -DestinationPath $Archive -Force
Get-Item $Archive | Select-Object Name, Length, LastWriteTime
