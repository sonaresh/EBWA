$ErrorActionPreference='Stop'
$Root=(Resolve-Path "$PSScriptRoot\..").Path
Set-Location $Root
Write-Host '[kind] checking cluster health'
powershell -ExecutionPolicy Bypass -File "$Root\scripts\kind-smoke.ps1"
Write-Host '[kind] running two-cluster EBWA validation'
python "$Root\scripts\kind_validate.py" --output-dir "$Root\evidence\kind-v1.3"
