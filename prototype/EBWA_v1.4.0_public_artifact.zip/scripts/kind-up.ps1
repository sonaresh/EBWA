$ErrorActionPreference='Stop'
$Root=(Resolve-Path "$PSScriptRoot\..").Path

foreach($c in @('ebwa-a','ebwa-b')){
  if(kind get clusters | Select-String -SimpleMatch $c){
    Write-Host "[kind] deleting existing cluster $c"
    kind delete cluster --name $c
  }
}

kind create cluster --config "$Root\kind\cluster-a.yaml"
kind create cluster --config "$Root\kind\cluster-b.yaml"

docker build -f "$Root\Dockerfile.gateway" -t ebwa-gateway:1.3.0 "$Root"
docker build -f "$Root\Dockerfile.resource" -t ebwa-resource:1.3.0 "$Root"
kind load docker-image ebwa-gateway:1.3.0 --name ebwa-a
kind load docker-image ebwa-resource:1.3.0 --name ebwa-a
kind load docker-image ebwa-gateway:1.3.0 --name ebwa-b
kind load docker-image ebwa-resource:1.3.0 --name ebwa-b

foreach($c in @('ebwa-a','ebwa-b')){
  $td=if($c -eq 'ebwa-a'){'prod.us-east'}else{'prod.us-west'}
  (Get-Content "$Root\k8s\base\namespace.yaml" -Raw).Replace('REPLACE_TRUST_DOMAIN',$td) | kubectl --context "kind-$c" apply -f -
  (Get-Content "$Root\k8s\base\gateway.yaml" -Raw).Replace('ebwa-gateway:1.0.0','ebwa-gateway:1.3.0') | kubectl --context "kind-$c" apply -f -
  (Get-Content "$Root\k8s\base\resource.yaml" -Raw).Replace('ebwa-resource:1.0.0','ebwa-resource:1.3.0') | kubectl --context "kind-$c" apply -f -
  kubectl --context "kind-$c" -n ebwa rollout status deploy/ebwa-gateway --timeout=180s
  kubectl --context "kind-$c" -n ebwa rollout status deploy/protected-resource --timeout=180s
}
Write-Host '[kind] Two EBWA clusters are running: ebwa-a/prod.us-east and ebwa-b/prod.us-west'
