$ErrorActionPreference='Stop'
foreach($c in @('ebwa-a','ebwa-b')){
  Write-Host "=== $c ==="
  kubectl --context "kind-$c" -n ebwa get pods,svc
  $pod=kubectl --context "kind-$c" -n ebwa get pod -l app=ebwa-gateway -o jsonpath='{.items[0].metadata.name}'
  kubectl --context "kind-$c" -n ebwa exec $pod -- python -c "import urllib.request; print(urllib.request.urlopen('http://127.0.0.1:8000/health').read().decode())"
}
