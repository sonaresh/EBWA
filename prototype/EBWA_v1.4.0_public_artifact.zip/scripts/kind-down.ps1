kind delete cluster --name ebwa-a
kind delete cluster --name ebwa-b
