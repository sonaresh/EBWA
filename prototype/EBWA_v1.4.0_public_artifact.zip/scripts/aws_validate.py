from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import statistics
import subprocess
import time
import uuid
from pathlib import Path

import httpx

ADMIN_TOKEN = os.getenv("EBWA_ADMIN_TOKEN", "ebwa-lab-admin")
ADMIN = {"x-ebwa-admin": ADMIN_TOKEN}
RESOURCE = "secret://payments/db"
ACTION = "read"
GOOD = "sha256:" + hashlib.sha256(b"payments-api:v1").hexdigest()
BAD = "sha256:" + hashlib.sha256(b"payments-api:tampered").hexdigest()


def percentile(xs: list[float], p: float) -> float:
    if not xs:
        return 0.0
    ys = sorted(xs)
    pos = (len(ys) - 1) * p
    lo = int(pos)
    hi = min(lo + 1, len(ys) - 1)
    frac = pos - lo
    return ys[lo] * (1 - frac) + ys[hi] * frac


def wait_http(url: str, timeout: float = 45.0) -> None:
    end = time.time() + timeout
    last = None
    while time.time() < end:
        try:
            r = httpx.get(url, timeout=2)
            if r.status_code == 200:
                return
            last = f"HTTP {r.status_code}"
        except Exception as exc:
            last = type(exc).__name__
        time.sleep(0.5)
    raise RuntimeError(f"timed out waiting for {url}: {last}")


def start_port_forward(context: str, namespace: str, service: str, local_port: int, remote_port: int) -> subprocess.Popen:
    cmd = [
        "kubectl", "--context", context, "-n", namespace, "port-forward",
        f"service/{service}", f"{local_port}:{remote_port}", "--address", "127.0.0.1",
    ]
    return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def post(url: str, path: str, payload: dict, admin: bool = False) -> httpx.Response:
    return httpx.post(url + path, headers=ADMIN if admin else None, json=payload, timeout=15)


def seed(gateway: str, trust_domain: str, tag: str) -> str:
    workload_id = "payments-api"
    rows = [
        ("/v1/admin/provenance", {
            "artifact_digest": GOOD,
            "source_repo": "https://example.invalid/ebwa-aws",
            "commit_sha": tag,
            "builder_id": f"builder://{trust_domain}",
            "slsa_level": 3,
            "ttl_seconds": 7200,
        }),
        ("/v1/admin/policy", {
            "resource": RESOURCE,
            "action": ACTION,
            "allowed_trust_domains": [trust_domain],
            "required_scope": "secret:read",
            "require_fresh": False,
            "require_isolation": False,
            "version": tag,
        }),
        ("/v1/admin/posture", {
            "workload_id": workload_id,
            "healthy": True,
            "isolation_ok": True,
            "telemetry_ok": True,
            "ttl_seconds": 7200,
            "reason": "aws healthy",
        }),
    ]
    for path, payload in rows:
        r = post(gateway, path, payload, admin=True)
        r.raise_for_status()
    r = post(gateway, "/v1/admin/identity", {
        "workload_id": workload_id,
        "trust_domain": trust_domain,
        "artifact_digest": GOOD,
        "scopes": ["secret:read"],
        "ttl_seconds": 7200,
    }, admin=True)
    r.raise_for_status()
    return r.json()["token"]


def issue_identity(gateway: str, trust_domain: str, artifact: str = GOOD, scopes=None) -> str:
    r = post(gateway, "/v1/admin/identity", {
        "workload_id": "payments-api",
        "trust_domain": trust_domain,
        "artifact_digest": artifact,
        "scopes": scopes if scopes is not None else ["secret:read"],
        "ttl_seconds": 7200,
    }, admin=True)
    r.raise_for_status()
    return r.json()["token"]


def authorize(gateway: str, token: str, artifact: str = GOOD, config: str = "D", force_fresh: bool = True) -> tuple[dict, float]:
    t0 = time.perf_counter()
    r = post(gateway, "/v1/authorize", {
        "identity_token": token,
        "artifact_digest": artifact,
        "resource": RESOURCE,
        "action": ACTION,
        "config": config,
        "request_id": str(uuid.uuid4()),
        "force_fresh": force_fresh,
    })
    rtt = (time.perf_counter() - t0) * 1000.0
    r.raise_for_status()
    return r.json(), rtt


def set_posture(gateway: str, healthy: bool, isolation_ok: bool = True, reason: str = "test") -> None:
    r = post(gateway, "/v1/admin/posture", {
        "workload_id": "payments-api",
        "healthy": healthy,
        "isolation_ok": isolation_ok,
        "telemetry_ok": True,
        "ttl_seconds": 7200,
        "reason": reason,
    }, admin=True)
    r.raise_for_status()


def set_plane(gateway: str, plane: str, state: str) -> None:
    r = httpx.post(gateway + f"/v1/admin/planes/{plane}/{state}", headers=ADMIN, timeout=15)
    r.raise_for_status()


def resource_call(resource_url: str, token: str, artifact: str = GOOD, config: str = "D") -> tuple[int, dict, float]:
    t0 = time.perf_counter()
    r = httpx.post(
        resource_url + "/v1/secret",
        headers={"Authorization": "Bearer " + token},
        json={"artifact_digest": artifact, "config": config},
        timeout=15,
    )
    rtt = (time.perf_counter() - t0) * 1000.0
    try:
        body = r.json()
    except Exception:
        body = {"text": r.text}
    return r.status_code, body, rtt


def perf_sample(gateway: str, token: str, repetitions: int) -> dict:
    server = []
    rtt = []
    for _ in range(repetitions):
        body, elapsed = authorize(gateway, token, config="D", force_fresh=True)
        if body["decision"] != "ALLOW":
            raise RuntimeError(f"performance sample unexpectedly denied: {body}")
        server.append(float(body.get("latency_ms", 0.0)))
        rtt.append(elapsed)
    return {
        "repetitions": repetitions,
        "server_latency_ms": {
            "p50": percentile(server, 0.50),
            "p95": percentile(server, 0.95),
            "p99": percentile(server, 0.99),
            "mean": statistics.fmean(server),
        },
        "client_portforward_rtt_ms": {
            "p50": percentile(rtt, 0.50),
            "p95": percentile(rtt, 0.95),
            "p99": percentile(rtt, 0.99),
            "mean": statistics.fmean(rtt),
        },
        "note": "Client RTT includes kubectl port-forward overhead; server latency is the primary AWS authorization timing signal.",
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="EBWA AWS EKS two-namespace external validation")
    ap.add_argument("--output-dir", default="evidence/aws-v1.4")
    ap.add_argument("--context", required=True)
    ap.add_argument("--namespace-a", default="ebwa-east")
    ap.add_argument("--namespace-b", default="ebwa-west")
    ap.add_argument("--trust-domain-a", default="aws.prod.us-east")
    ap.add_argument("--trust-domain-b", default="aws.prod.us-west")
    ap.add_argument("--gateway-a-port", type=int, default=18080)
    ap.add_argument("--gateway-b-port", type=int, default=28080)
    ap.add_argument("--resource-a-port", type=int, default=18081)
    ap.add_argument("--resource-b-port", type=int, default=28081)
    ap.add_argument("--perf-repetitions", type=int, default=500)
    args = ap.parse_args()

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    results: list[dict] = []
    procs = []
    try:
        procs = [
            start_port_forward(args.context, args.namespace_a, "ebwa-gateway", args.gateway_a_port, 8000),
            start_port_forward(args.context, args.namespace_b, "ebwa-gateway", args.gateway_b_port, 8000),
            start_port_forward(args.context, args.namespace_a, "protected-resource", args.resource_a_port, 8001),
            start_port_forward(args.context, args.namespace_b, "protected-resource", args.resource_b_port, 8001),
        ]
        ga = f"http://127.0.0.1:{args.gateway_a_port}"
        gb = f"http://127.0.0.1:{args.gateway_b_port}"
        ra = f"http://127.0.0.1:{args.resource_a_port}"
        rb = f"http://127.0.0.1:{args.resource_b_port}"
        for url in (ga + "/health", gb + "/health", ra + "/health", rb + "/health"):
            wait_http(url)

        print("[aws] seeding independent EBWA authorization roots")
        token_a = seed(ga, args.trust_domain_a, "aws-v1.4-a")
        token_b = seed(gb, args.trust_domain_b, "aws-v1.4-b")

        def record(name: str, expected: str, observed: str, detail: str, server_latency_ms=None, client_rtt_ms=None):
            ok = expected == observed
            row = {
                "test": name,
                "expected": expected,
                "observed": observed,
                "pass": ok,
                "detail": detail,
                "server_latency_ms": server_latency_ms,
                "client_rtt_ms": client_rtt_ms,
            }
            results.append(row)
            print(f"{'PASS' if ok else 'FAIL'} {name}: expected={expected} observed={observed} {detail}")

        sc, _, rtt = resource_call(ra, token_a)
        record("A01 namespace-A legitimate resource access", "ALLOW", "ALLOW" if sc == 200 else "DENY", f"HTTP {sc}", client_rtt_ms=rtt)
        sc, _, rtt = resource_call(rb, token_b)
        record("A02 namespace-B legitimate resource access", "ALLOW", "ALLOW" if sc == 200 else "DENY", f"HTTP {sc}", client_rtt_ms=rtt)

        body, rtt = authorize(gb, token_a)
        record("A03 cross-root credential replay A->B", "DENY", body["decision"], body["reason"], body.get("latency_ms"), rtt)

        wrong = issue_identity(gb, args.trust_domain_a)
        body, rtt = authorize(gb, wrong)
        record("A04 trust-domain separation in B", "DENY", body["decision"], body["reason"], body.get("latency_ms"), rtt)

        body, rtt = authorize(ga, token_a, artifact=BAD)
        record("A05 artifact substitution", "DENY", body["decision"], body["reason"], body.get("latency_ms"), rtt)

        no_scope = issue_identity(ga, args.trust_domain_a, scopes=["telemetry:read"])
        body, rtt = authorize(ga, no_scope)
        record("A06 insufficient scope", "DENY", body["decision"], body["reason"], body.get("latency_ms"), rtt)

        set_plane(ga, "provenance", "down")
        try:
            body, rtt = authorize(ga, token_a)
            record("A07 provenance-plane outage fail closed", "DENY", body["decision"], body["reason"], body.get("latency_ms"), rtt)
        finally:
            set_plane(ga, "provenance", "up")

        set_posture(ga, True, True, "cache warm")
        warm, _ = authorize(ga, token_a, force_fresh=False)
        if warm["decision"] != "ALLOW":
            raise RuntimeError("A08 setup failed: initial authorization was not ALLOW")
        set_posture(ga, False, True, "runtime drift")
        body, rtt = authorize(ga, token_a, force_fresh=False)
        record("A08 posture drift invalidates cached allow", "DENY", body["decision"], f"cache_hit={body.get('cache_hit')} {body['reason']}", body.get("latency_ms"), rtt)
        set_posture(ga, True, True, "restored")

        set_posture(ga, True, False, "isolation degraded")
        bd, rd = authorize(ga, token_a, config="D")
        be, re = authorize(ga, token_a, config="E")
        record("A09a isolation degraded under D", "ALLOW", bd["decision"], bd["reason"], bd.get("latency_ms"), rd)
        record("A09b isolation degraded under E", "DENY", be["decision"], be["reason"], be.get("latency_ms"), re)
        set_posture(ga, True, True, "restored")

        sc, _, rtt = resource_call(ra, token_a, artifact=BAD)
        record("A10 protected-resource enforcement", "DENY", "DENY" if sc == 403 else "ALLOW", f"HTTP {sc}", client_rtt_ms=rtt)

        perf = {
            args.namespace_a: perf_sample(ga, token_a, args.perf_repetitions),
            args.namespace_b: perf_sample(gb, token_b, args.perf_repetitions),
        }

        summary = {
            "benchmark_version": "1.4.0",
            "environment": "AWS EKS external validation",
            "context": args.context,
            "namespace_a": args.namespace_a,
            "namespace_b": args.namespace_b,
            "trust_domain_a": args.trust_domain_a,
            "trust_domain_b": args.trust_domain_b,
            "tests_passed": sum(1 for r in results if r["pass"]),
            "tests_total": len(results),
            "results": results,
            "performance": perf,
            "method_note": "Two namespaces run independent EBWA gateway state and signing roots on one short-lived EKS cluster. This validates AWS execution and trust-root separation; it is not a two-region or two-cluster AWS claim.",
        }
        (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
        with (out / "results.csv").open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(results[0].keys()))
            w.writeheader()
            w.writerows(results)
        print(f"[done] {summary['tests_passed']}/{summary['tests_total']} tests passed; evidence written to {out}")
        print(json.dumps(summary["performance"], indent=2))
        return 0 if summary["tests_passed"] == summary["tests_total"] else 2
    finally:
        for p in procs:
            try:
                p.terminate()
            except Exception:
                pass
        for p in procs:
            try:
                p.wait(timeout=3)
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main())
