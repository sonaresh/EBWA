param(
  [Parameter(Mandatory=$true)]
  [string]$Profile,

  [string]$Region = "us-east-2",

  [string]$ClusterName = "ebwa-external-v14"
)

$ErrorActionPreference = "Stop"

function Require-Command([string]$Name) {
  if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
    throw "Required command not found: $Name"
  }
}

function Assert-LastExitCode([string]$Message) {
  if ($LASTEXITCODE -ne 0) {
    throw "$Message (exit code $LASTEXITCODE)"
  }
}

Require-Command aws
Require-Command eksctl
Require-Command kubectl
Require-Command docker

$env:AWS_PROFILE = $Profile
$env:AWS_REGION = $Region

# -------------------------------------------------------------------
# Resolve AWS account
# -------------------------------------------------------------------

$AccountId = (
  aws sts get-caller-identity `
    --profile $Profile `
    --query Account `
    --output text
).Trim()

Assert-LastExitCode "Unable to retrieve AWS caller identity"

if (-not $AccountId) {
  throw "Could not resolve AWS account ID"
}

Write-Host "[aws] account=$AccountId region=$Region profile=$Profile"

# -------------------------------------------------------------------
# Render eksctl configuration
# -------------------------------------------------------------------

$ClusterTemplate = "k8s\aws\eksctl-cluster.yaml"
$RenderedClusterConfig = "k8s\aws\eksctl-cluster.rendered.yaml"

if (-not (Test-Path $ClusterTemplate)) {
  throw "Cluster template not found: $ClusterTemplate"
}

$cfg = Get-Content $ClusterTemplate -Raw
$cfg = $cfg.Replace("__CLUSTER_NAME__", $ClusterName)
$cfg = $cfg.Replace("__REGION__", $Region)

$cfg | Set-Content $RenderedClusterConfig -Encoding utf8

# -------------------------------------------------------------------
# Check/create EKS cluster
# -------------------------------------------------------------------

Write-Host "[aws] checking whether EKS cluster exists: $ClusterName"

$exists = $false

try {
  $clusterJson = eksctl get cluster `
    --region $Region `
    --profile $Profile `
    -o json 2>$null

  if ($LASTEXITCODE -eq 0 -and $clusterJson) {
    $clusters = @($clusterJson | ConvertFrom-Json)

    foreach ($c in $clusters) {
      if ($c.Name -eq $ClusterName) {
        $exists = $true
        break
      }
    }
  }
}
catch {
  $exists = $false
}

if (-not $exists) {
  Write-Host "[aws] creating short-lived EKS cluster $ClusterName"

  eksctl create cluster `
    -f $RenderedClusterConfig `
    --profile $Profile

  Assert-LastExitCode "EKS cluster creation failed"
}
else {
  Write-Host "[aws] cluster already exists: $ClusterName"
}

# -------------------------------------------------------------------
# Update kubeconfig and resolve kubectl context
# -------------------------------------------------------------------

aws eks update-kubeconfig `
  --name $ClusterName `
  --region $Region `
  --profile $Profile | Out-Host

Assert-LastExitCode "Failed to update kubeconfig"

$Context = (
  kubectl config get-contexts -o name |
  Where-Object { $_ -like "*$ClusterName*" } |
  Select-Object -First 1
)

if (-not $Context) {
  throw "Could not resolve kubectl context for $ClusterName"
}

Write-Host "[aws] kubectl context=$Context"

# -------------------------------------------------------------------
# Verify EKS node readiness
# -------------------------------------------------------------------

Write-Host "[aws] checking EKS nodes"

kubectl --context $Context get nodes -o wide | Out-Host
Assert-LastExitCode "Unable to query EKS nodes"

# -------------------------------------------------------------------
# ECR repositories
# -------------------------------------------------------------------

$GatewayRepo = "ebwa-gateway"
$ResourceRepo = "ebwa-resource"

foreach ($repo in @($GatewayRepo, $ResourceRepo)) {

  Write-Host "[aws] checking ECR repository: $repo"

  $repoExists = $false

  try {
    $null = aws ecr describe-repositories `
      --repository-names $repo `
      --region $Region `
      --profile $Profile `
      --output json 2>$null

    if ($LASTEXITCODE -eq 0) {
      $repoExists = $true
    }
  }
  catch {
    $repoExists = $false
  }

  if ($repoExists) {
    Write-Host "[aws] ECR repo already exists: $repo"
  }
  else {
    Write-Host "[aws] creating ECR repo: $repo"

    aws ecr create-repository `
      --repository-name $repo `
      --image-scanning-configuration scanOnPush=true `
      --region $Region `
      --profile $Profile `
      --output json | Out-Null

    Assert-LastExitCode "Failed to create ECR repository: $repo"

    Write-Host "[aws] created ECR repo $repo"
  }
}

# -------------------------------------------------------------------
# ECR login
# -------------------------------------------------------------------

$Registry = "$AccountId.dkr.ecr.$Region.amazonaws.com"

Write-Host "[aws] logging Docker into ECR registry $Registry"

$password = aws ecr get-login-password `
  --region $Region `
  --profile $Profile

Assert-LastExitCode "Failed to retrieve ECR login password"

$password |
  docker login `
    --username AWS `
    --password-stdin $Registry |
  Out-Host

Assert-LastExitCode "Docker ECR login failed"

# -------------------------------------------------------------------
# Build images
# -------------------------------------------------------------------

Write-Host "[aws] building EBWA gateway image"

docker build `
  -f Dockerfile.gateway `
  -t ebwa-gateway:1.4.0 .

Assert-LastExitCode "Gateway Docker build failed"

Write-Host "[aws] building EBWA protected-resource image"

docker build `
  -f Dockerfile.resource `
  -t ebwa-resource:1.4.0 .

Assert-LastExitCode "Resource Docker build failed"

# -------------------------------------------------------------------
# Tag images
# -------------------------------------------------------------------

$GatewayImage = "$Registry/$GatewayRepo`:1.4.0"
$ResourceImage = "$Registry/$ResourceRepo`:1.4.0"

docker tag ebwa-gateway:1.4.0 $GatewayImage
Assert-LastExitCode "Failed to tag gateway image"

docker tag ebwa-resource:1.4.0 $ResourceImage
Assert-LastExitCode "Failed to tag resource image"

# -------------------------------------------------------------------
# Push images
# -------------------------------------------------------------------

Write-Host "[aws] pushing gateway image: $GatewayImage"

docker push $GatewayImage
Assert-LastExitCode "Failed to push gateway image"

Write-Host "[aws] pushing resource image: $ResourceImage"

docker push $ResourceImage
Assert-LastExitCode "Failed to push resource image"

# -------------------------------------------------------------------
# Deploy EBWA namespaces
# -------------------------------------------------------------------

$AdminToken = "ebwa-lab-admin"

$Namespaces = @(
  "ebwa-east",
  "ebwa-west"
)

$ManifestTemplate = "k8s\aws\gateway-resource-template.yaml"

if (-not (Test-Path $ManifestTemplate)) {
  throw "AWS Kubernetes manifest template missing: $ManifestTemplate"
}

foreach ($ns in $Namespaces) {

  Write-Host "[aws] deploying namespace: $ns"

  kubectl --context $Context `
    create namespace $ns `
    --dry-run=client `
    -o yaml |
    kubectl --context $Context apply -f - |
    Out-Host

  Assert-LastExitCode "Failed to create namespace $ns"

  kubectl --context $Context `
    -n $ns `
    create secret generic ebwa-admin `
    --from-literal=token=$AdminToken `
    --dry-run=client `
    -o yaml |
    kubectl --context $Context apply -f - |
    Out-Host

  Assert-LastExitCode "Failed to create EBWA admin secret in $ns"

  $manifest = Get-Content $ManifestTemplate -Raw

  $manifest = $manifest.Replace("__NAMESPACE__", $ns)
  $manifest = $manifest.Replace("__GATEWAY_IMAGE__", $GatewayImage)
  $manifest = $manifest.Replace("__RESOURCE_IMAGE__", $ResourceImage)

  $rendered = "k8s\aws\$ns.rendered.yaml"

  $manifest |
    Set-Content $rendered -Encoding utf8

  kubectl --context $Context apply -f $rendered | Out-Host
  Assert-LastExitCode "Failed to deploy EBWA resources in $ns"

  Write-Host "[aws] waiting for gateway rollout in $ns"

  kubectl --context $Context `
    -n $ns `
    rollout status deployment/ebwa-gateway `
    --timeout=300s |
    Out-Host

  Assert-LastExitCode "Gateway rollout failed in $ns"

  Write-Host "[aws] waiting for protected-resource rollout in $ns"

  kubectl --context $Context `
    -n $ns `
    rollout status deployment/protected-resource `
    --timeout=300s |
    Out-Host

  Assert-LastExitCode "Protected-resource rollout failed in $ns"
}

# -------------------------------------------------------------------
# Verify workloads
# -------------------------------------------------------------------

foreach ($ns in $Namespaces) {
  Write-Host ""
  Write-Host "=== $ns ==="

  kubectl --context $Context `
    -n $ns `
    get pods,svc -o wide |
    Out-Host

  Assert-LastExitCode "Failed to inspect namespace $ns"
}

# -------------------------------------------------------------------
# Evidence bootstrap
# -------------------------------------------------------------------

$EvidenceDir = "evidence\aws-v1.4"

New-Item `
  -ItemType Directory `
  -Force `
  -Path $EvidenceDir |
  Out-Null

$EnvironmentEvidence = @{
  benchmark_version = "1.4.0"
  profile           = $Profile
  region            = $Region
  account_id        = $AccountId
  cluster_name      = $ClusterName
  kubectl_context   = $Context
  gateway_image     = $GatewayImage
  resource_image    = $ResourceImage
  namespaces        = $Namespaces
  timestamp_utc     = (Get-Date).ToUniversalTime().ToString("o")
}

$EnvironmentEvidence |
  ConvertTo-Json -Depth 5 |
  Set-Content `
    "$EvidenceDir\environment-bootstrap.json" `
    -Encoding utf8

kubectl --context $Context get nodes -o wide |
  Out-File "$EvidenceDir\nodes.txt"

kubectl --context $Context get pods -A -o wide |
  Out-File "$EvidenceDir\pods-all-namespaces.txt"

aws eks describe-cluster `
  --name $ClusterName `
  --region $Region `
  --profile $Profile `
  --output json |
  Out-File "$EvidenceDir\eks-cluster.json"

# -------------------------------------------------------------------
# Completion
# -------------------------------------------------------------------

Write-Host ""
Write-Host "======================================================"
Write-Host "[aws] EBWA EKS environment ready"
Write-Host "[aws] cluster=$ClusterName"
Write-Host "[aws] context=$Context"
Write-Host "[aws] namespaces=ebwa-east,ebwa-west"
Write-Host "[aws] gateway=$GatewayImage"
Write-Host "[aws] resource=$ResourceImage"
Write-Host "[aws] evidence=$EvidenceDir"
Write-Host "======================================================"