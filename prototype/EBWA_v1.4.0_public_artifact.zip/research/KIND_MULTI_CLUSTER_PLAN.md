# EBWA v1.3 — Two-Cluster kind Validation Plan

## Objective
Validate the security semantics that are not demonstrated by a single-process benchmark: two independent Kubernetes clusters, two trust domains, protected-resource enforcement, cross-cluster credential replay resistance, trust-domain policy separation, fail-closed evidence-plane behavior, and cache invalidation after runtime drift.

## Topology

- `ebwa-a` — kind cluster, namespace `ebwa`, trust domain `prod.us-east`
- `ebwa-b` — kind cluster, namespace `ebwa`, trust domain `prod.us-west`
- Each cluster runs an independent EBWA gateway and protected resource.
- Each gateway creates its own identity/provenance signing keys. This intentionally models independent trust roots for the cross-cluster replay test.

## Validation cases

| ID | Experiment | Expected |
|---|---|---|
| K01 | Legitimate protected-resource request in cluster A | ALLOW |
| K02 | Legitimate protected-resource request in cluster B | ALLOW |
| K03 | Replay A-issued credential against cluster B | DENY |
| K04 | B-signed credential carrying A trust-domain | DENY |
| K05 | Artifact substitution | DENY |
| K06 | Insufficient scope | DENY |
| K07 | Provenance evidence plane outage | DENY |
| K08 | Cached allow followed by posture degradation | DENY after invalidation |
| K09a | Isolation degradation under D | ALLOW |
| K09b | Isolation degradation under E | DENY |
| K10 | Tampered artifact through protected-resource API | DENY |

## Interpretation boundary

K03 demonstrates replay resistance across two independently keyed cluster trust roots. K04 separately isolates trust-domain policy enforcement using a destination-cluster-signed identity. The study is a local multi-cluster functional/security validation; it is not evidence of public-cloud scale, WAN behavior, or concurrent production throughput.

## Evidence artifacts

`scripts/kind_validate.py` writes:

- `evidence/kind-v1.3/summary.json`
- `evidence/kind-v1.3/results.csv`

Use the generated artifacts only after confirming `all_passed: true` and recording Docker, kind, kubectl, Kubernetes, Python, and host environment versions.
