# EBWA AWS External Validation Plan (v1.4.0)

## Goal
Validate that the EBWA authorization invariant demonstrated locally and in two-kind-cluster experiments also holds when deployed to a real AWS EKS environment.

## Environment
One short-lived EKS cluster with one managed `t3.medium` node group and two namespaces:

- `ebwa-east` — trust domain `aws.prod.us-east`
- `ebwa-west` — trust domain `aws.prod.us-west`

Each namespace has an independent EBWA gateway state directory and therefore an independent signing root. The two namespaces intentionally model isolated authorization roots within a single external AWS cluster. This is **not** a two-region or two-EKS-cluster experiment.

No public LoadBalancer is created. Services remain `ClusterIP`; validation uses `kubectl port-forward`. The cluster config uses public worker networking to avoid introducing a NAT Gateway solely for this short experiment.

## Security tests
A01 legitimate access in namespace A
A02 legitimate access in namespace B
A03 A-issued credential replayed into B -> DENY
A04 wrong trust domain signed by B -> DENY
A05 artifact substitution -> DENY
A06 insufficient scope -> DENY
A07 provenance plane outage -> fail closed
A08 cached ALLOW invalidated by posture drift
A09a isolation degradation under D -> ALLOW
A09b isolation degradation under E -> DENY
A10 protected resource rejects tampered artifact

## Performance sample
The validation script additionally executes repeated fresh configuration-D authorization requests in each namespace and records:

- server-reported authorization p50/p95/p99
- client-observed port-forward p50/p95/p99

The server-reported value is the primary AWS authorization timing signal. Port-forward RTT is explicitly labeled as diagnostic because it includes kubectl transport overhead and is not a production network benchmark.

## Evidence
- `evidence/aws-v1.4/summary.json`
- `evidence/aws-v1.4/results.csv`
- environment metadata and logs from `aws-collect-evidence.ps1`
- `evidence/EBWA-AWS-v1.4-evidence.zip`

## Scientific boundaries
The experiment supports an external AWS execution claim, EKS deployment reproducibility, independent authorization-root separation, and security-invariant validation. It must not be described as multi-region AWS, two-cluster AWS, or production-concurrency benchmarking.
