# Manuscript-to-Prototype Mapping

| Manuscript element | Prototype evidence |
|---|---|
| Authorization invariant Eq. (1) | `ebwa/engine.py`, config D/E predicates |
| EBAR Eq. (2) | `ebwa/metrics.py::ebar` |
| NDE Eq. (3) | `ebwa/metrics.py::nde`; drift scenarios S05/S06/S19/S20 |
| SDO95 Eq. (4) | `ebwa/metrics.py::sdo95`, `ebwa/benchmark.py` |
| Identity evidence | Ed25519 JWT workload identity |
| Exact artifact binding | identity `artifact_digest` compared to request digest |
| Provenance evidence | Ed25519-signed SLSA-like provenance envelope |
| Policy | resource/action/trust-domain/scope policy object |
| Runtime posture | health, telemetry, isolation, TTL |
| Continuous feedback | evidence-version invalidation clears cached decisions |
| Revocation | identity/workload/artifact/signer revocations |
| A/B/C/D/E ablation | `AuthorizationRequest.config` |
| Cross-control attacks | `ebwa/scenarios.py` |
| Multi-cluster / trust domains | `kind/` + `scripts/kind-up.ps1` |
| Reproducibility | scenario JSON, benchmark CSV/JSON, fixed release tree |
