# EBWA Empirical Experiment Plan — v1.1

## Objective

Produce reproducible evidence for RQ1–RQ4 without fabricating performance, scale, or security claims.

## Phase 1 — Core correctness

1. `python -m ebwa.seed --reset`
2. `python -m pytest -q`
3. Archive terminal output and software versions.

Acceptance: all automated tests pass.

## Phase 2 — Security ablation

Run:

```text
python -m ebwa.scenario_runner --all --output evidence/scenarios.json
```

Evaluate all 20 scenarios across configurations A–E. The analysis must distinguish attacks prevented by identity, provenance, runtime evidence binding, and stronger isolation.

## Phase 3 — Controlled local performance

Run at scale=1000 with 5 independent trials, 100 warm-up rounds, and both fresh/cached modes. Preserve raw latency rows and summary files.

Primary outputs:

- EBAR for D/E
- paired SDO95
- p95(D)-p95(A)
- p50/p95/p99 by configuration and cache mode
- cache hit rate
- trial-level confidence intervals
- CPU time and Python allocator peak
- revocation propagation p50/p95/p99
- NDE

The paired latency design uses the same logical workload for A–E in each round and randomizes execution order to reduce ordering bias.

## Phase 4 — Scale progression

Run 1k then 10k instantiated workload/posture objects. If stable, continue to larger logical scale. Record the actual instantiated dimensions written to `scale_dimensions`; never describe `--scale` as physical application count.

## Phase 5 — Multi-cluster local validation

Deploy the provider-neutral contract to two kind clusters. Confirm health, protected-resource access, trust-domain separation, and teardown.

## Phase 6 — External environment validation

Use the user's AWS research lab only after local results are frozen. Record account/profile, region, infrastructure manifests, image digests, tool versions, timestamps, and complete teardown evidence. Do not infer multi-cloud/provider-neutral validation from Kubernetes alone.

## Reporting discipline

- No hypothetical percentages.
- No cherry-picked fastest trial.
- Report all trial parameters and confidence intervals.
- Preserve raw data and failed traces.
- State what was physically instantiated versus synthetically generated.
- Do not claim production throughput from single-process local Python results.
