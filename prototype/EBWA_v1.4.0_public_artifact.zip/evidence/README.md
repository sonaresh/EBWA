# Generated evidence

This directory is intentionally empty in source control. Benchmark and scenario commands write reproducible outputs here.
